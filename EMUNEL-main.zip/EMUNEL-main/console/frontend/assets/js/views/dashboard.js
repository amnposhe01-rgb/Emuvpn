import { api, statusEl, fmtWhen, esc, toast, copyButton, TRANSITION_STATES } from "../api.js";
import { setCleanup } from "../app.js";

// Real user-path latency: the browser fetches a tiny public endpoint and we
// time the round trip. This measures the operator's actual path to the
// server (Iran -> Railway edge -> app), which is exactly the leg a proxy
// client pays on every request — the honest "ping" number.
async function measureEdgeRtt() {
  const el = document.getElementById("edge-rtt");
  if (!el) return null;
  el.innerHTML = `<span class="faint">measuring…</span>`;
  const samples = [];
  for (let i = 0; i < 3; i++) {
    const t0 = performance.now();
    try {
      await fetch(`/version?_=${Date.now()}-${i}`, { cache: "no-store" });
    } catch {
      el.textContent = "unreachable";
      el.style.color = "var(--red)";
      return null;
    }
    samples.push(performance.now() - t0);
  }
  samples.sort((a, b) => a - b);
  const median = Math.round(samples[1]);
  el.innerHTML = `${median}<small> ms</small>`;
  el.style.color =
    median < 350 ? "var(--green)" : median < 900 ? "var(--amber)" : "var(--red)";
  return median;
}

function healthChip(h) {
  if (!h || !h.status) return "";
  const coreRtt = h.core && h.core.rtt_ms != null ? Math.round(h.core.rtt_ms) : null;
  const map = {
    healthy: ["var(--green)", "healthy"],
    degraded: ["var(--amber)", "degraded"],
    down: ["var(--red)", "down"],
    stopped: ["var(--amber)", "stopped"],
    "no-data": ["#8b94a7", "no data"],
    "no-endpoint": ["var(--amber)", "no endpoint"],
  };
  const [color, label] = map[h.status] || ["inherit", h.status];
  const rttPart = coreRtt != null ? ` · ${coreRtt}ms` : "";
  return `<span style="color:${color}">● ${label}${rttPart}</span>`;
}

export default {
  async render(root) {
    root.innerHTML = `
      <div class="page-head">
        <div>
          <h1>Dashboard</h1>
          <div class="sub">Your EMUNEL instances at a glance.</div>
        </div>
        <div class="head-actions">
          <a class="btn primary" href="#/instances/new" id="cta-create">+ Create Instance</a>
        </div>
      </div>
      <div class="stat-grid" id="stats"></div>
      <h3 style="margin:0 0 12px;font-size:14px">Instances</h3>
      <div id="inst-list"></div>
      <div class="card section-gap">
        <h3>Recent activity</h3>
        <div class="activity-feed" id="activity"></div>
      </div>`;

    let pollTimer = null;
    let healthMap = {};

    // Last-known health per running instance, from the monitoring loop's
    // cache (?cached=1 never probes — safe for the overview page).
    async function loadHealth(instances) {
      const running = instances.filter((i) => i.status === "running").slice(0, 8);
      const results = await Promise.allSettled(
        running.map((i) => api.get(`/api/instances/${i.id}/health?cached=1`))
      );
      healthMap = {};
      running.forEach((i, idx) => {
        if (results[idx].status === "fulfilled") healthMap[i.id] = results[idx].value;
      });
    }

    async function load() {
      const [{ instances }, { activity }] = await Promise.all([
        api.get("/api/instances"),
        api.get("/api/activity"),
      ]);

      const running = instances.filter((i) => i.status === "running").length;
      const stopped = instances.filter((i) => ["stopped", "deleted"].includes(i.status)).length;
      const failed = instances.filter((i) => i.status === "failed").length;
      const transitioning = instances.filter((i) => TRANSITION_STATES.has(i.status)).length;

      await loadHealth(instances);

      document.getElementById("stats").innerHTML = `
        <div class="stat"><div class="label">Active instances</div><div class="value">${instances.length}</div></div>
        <div class="stat"><div class="label">Running</div><div class="value" style="color:var(--green)">${running}</div></div>
        <div class="stat"><div class="label">Stopped</div><div class="value">${stopped}</div></div>
        <div class="stat"><div class="label">Failed</div><div class="value" style="color:${failed ? "var(--red)" : "inherit"}">${failed}</div></div>
        <div class="stat">
          <div class="label">Edge RTT <a href="#" id="reping" title="Re-measure your latency to the server" style="font-size:11px;opacity:.7">↻</a></div>
          <div class="value" id="edge-rtt"><span class="faint">—</span></div>
          <div class="label" style="margin-top:2px;opacity:.7">you → server, median of 3</div>
        </div>`;

      const reping = document.getElementById("reping");
      if (reping) {
        reping.addEventListener("click", (e) => {
          e.preventDefault();
          measureEdgeRtt();
        });
      }

      const list = document.getElementById("inst-list");
      if (instances.length === 0) {
        list.innerHTML = `
          <div class="empty">
            <div class="big">No instances yet</div>
            <div>Deploy your first EMUNEL Core instance in under a minute.</div>
            <div style="margin-top:16px"><a class="btn primary" href="#/instances/new">Create your first instance</a></div>
          </div>`;
      } else {
        list.innerHTML = `<div class="inst-grid">${instances.map((i) => instCard(i)).join("")}</div>`;
        list.querySelectorAll(".inst-card").forEach((card) => {
          card.addEventListener("click", () => {
            location.hash = `#/instances/${card.dataset.id}`;
          });
        });
        list.querySelectorAll(".copy-btn").forEach((btn) => {
          btn.addEventListener("click", (e) => e.stopPropagation());
        });
      }

      const feed = document.getElementById("activity");
      feed.innerHTML =
        activity.length === 0
          ? `<div class="faint" style="padding:10px 2px">Nothing yet.</div>`
          : activity
              .slice(0, 8)
              .map(
                (a) => `
            <div class="activity-item">
              <span class="when">${fmtWhen(a.ts)}</span>
              <span class="msg">${esc(a.message)}</span>
            </div>`
              )
              .join("");
    }

    function instCard(i) {
      const endpoint = i.domain
        ? (i.endpoint_url || `https://${i.domain}`)
        : null;
      const chip = i.status === "running" ? healthChip(healthMap[i.id]) : "";
      return `
        <div class="inst-card" data-id="${i.id}">
          <div class="top">
            <span class="name">${esc(i.name)}</span>
            ${statusEl(i.status).outerHTML}
          </div>
          ${
            endpoint
              ? `<div class="endpoint"><span>${esc(endpoint)}</span>${copyButton(endpoint).outerHTML}</div>`
              : `<div class="endpoint faint"><span>no endpoint yet</span></div>`
          }
          <div class="meta">
            <span>${esc(i.region)}</span>
            <span>${i.deployments_count} deploys</span>
            <span>created ${fmtWhen(i.created_at)}</span>
            ${chip ? `<span>${chip}</span>` : ""}
          </div>
        </div>`;
    }

    await load();
    measureEdgeRtt();

    // Poll while any instance is transitioning so statuses stay honest.
    pollTimer = setInterval(async () => {
      try {
        const { instances } = await api.get("/api/instances");
        if (instances.some((i) => TRANSITION_STATES.has(i.status))) {
          await load();
        }
      } catch {
        /* transient */
      }
    }, 4000);
    setCleanup(() => clearInterval(pollTimer));

    root.querySelector("#cta-create").addEventListener("click", () => {});
    return () => clearInterval(pollTimer);
  },
};

"""Config Health Monitor — is anything actually listening at the endpoints?

"Why do the configs not ping" has two halves and this service answers the
SERVER half with measurements instead of guesses:

  * core liveness  — the instance's proxy Core answering /health through its
    worker route (works on every deployment, needs no public host)
  * public path   — an HTTPS GET through the real public URL (Railway edge
    -> console -> gateway -> worker -> core), only when a public host is
    known (instance column, ?host= hint from the panel UI)
  * REALITY route — a TCP connect to the REALITY public proxy when
    REALITY_PUBLIC_HOST is configured (the runtime clients actually dial)

The monitor is deliberately boring and bounded:

  * ONE background task for the whole console (lazy-started on the first
    health API call; exits by itself after 3 idle cycles and is restarted
    lazily — no forever-tasks for idle panels)
  * <= EMUNEL_HEALTH_MAX_PER_CYCLE probes per cycle (round-robin over
    instances), 5s timeout each, one shared httpx client per event loop
  * per-instance history is a deque(maxlen=60) — 30 minutes at the default
    30s interval, hard-bounded memory regardless of uptime
  * states for instances that stop running are garbage-collected every cycle

The IRAN half (DPI resetting handshakes, datacenter-IP throttling) cannot be
measured from inside the panel; docs/IRAN.md is the companion for that.
"""
from __future__ import annotations

import asyncio
import os
import time
import weakref
from collections import deque
from datetime import datetime, timezone

import httpx

from ..logging import get
from .irantune import reality_public_target
from .workers import WorkerError, worker_call, worker_url_for

log = get("runtime", "emunel.console.health")


def _clamp_int(name: str, default: int, lo: int, hi: int) -> int:
    try:
        v = int(os.environ.get(name, "") or default)
    except ValueError:
        return default
    return max(lo, min(hi, v))


INTERVAL_S = _clamp_int("EMUNEL_HEALTH_INTERVAL", 30, 15, 600)
PROBE_TIMEOUT_S = 5.0
MAX_PER_CYCLE = _clamp_int("EMUNEL_HEALTH_MAX_PER_CYCLE", 16, 1, 128)
IDLE_CYCLES_BEFORE_EXIT = 3
HISTORY_LEN = 60
RTT_DEGRADED_MS = 1500.0

# one bounded shared client per event loop (the v1.4.1 churn lesson)
_clients_by_loop: "weakref.WeakKeyDictionary" = weakref.WeakKeyDictionary()


def _probe_client() -> httpx.AsyncClient:
    loop = asyncio.get_running_loop()
    client = _clients_by_loop.get(loop)
    if client is None or client.is_closed:
        client = httpx.AsyncClient(
            timeout=httpx.Timeout(connect=PROBE_TIMEOUT_S, read=PROBE_TIMEOUT_S,
                                  write=PROBE_TIMEOUT_S, pool=PROBE_TIMEOUT_S),
            limits=httpx.Limits(max_connections=8, max_keepalive_connections=4),
            follow_redirects=False,
        )
        _clients_by_loop[loop] = client
    return client


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class _HealthMonitor:
    """Singleton probe loop (one per console process)."""

    def __init__(self) -> None:
        self._task: asyncio.Task | None = None
        self._start_lock = asyncio.Lock()
        self._states: dict[str, dict] = {}
        self._cursor = 0
        self._idle_cycles = 0
        self._reality: dict | None = None  # last reality probe result

    # ── lifecycle ────────────────────────────────────────────────────────
    async def ensure_started(self, pool) -> None:
        if self._task is not None and not self._task.done():
            return
        async with self._start_lock:
            if self._task is not None and not self._task.done():
                return
            self._task = asyncio.create_task(self._loop(pool))

    def stop(self) -> None:
        """Test hook — cancel and forget the loop."""
        if self._task is not None and not self._task.done():
            self._task.cancel()
        self._task = None
        self._states.clear()
        self._reality = None

    # ── probe primitives ─────────────────────────────────────────────────
    async def _probe_core(self, instance_id: str, node_id: str) -> dict:
        t0 = time.perf_counter()
        try:
            await worker_call(
                worker_url_for(node_id), "GET",
                f"/worker/api/instances/{instance_id}/proxy/health",
                timeout=PROBE_TIMEOUT_S,
            )
        except (WorkerError, OSError) as exc:
            return {"ok": False, "error": str(exc)[:160], "checked_at": _now_iso()}
        return {"ok": True, "rtt_ms": round((time.perf_counter() - t0) * 1000, 1),
                "checked_at": _now_iso()}

    async def _probe_public(self, host: str, token: str) -> dict:
        url = f"https://{host}/i/{token}"
        t0 = time.perf_counter()
        try:
            resp = await _probe_client().get(url)
        except (httpx.HTTPError, OSError) as exc:
            return {"ok": False, "error": type(exc).__name__, "url": url,
                    "checked_at": _now_iso()}
        rtt = round((time.perf_counter() - t0) * 1000, 1)
        ok = resp.status_code < 400  # 200 = running, 503 = stopped page: both prove the path
        return {"ok": ok, "http_status": resp.status_code, "rtt_ms": rtt,
                "url": url, "checked_at": _now_iso()}

    async def _probe_reality(self) -> dict:
        target = reality_public_target()
        if target is None:
            return {"status": "not-configured"}
        host, port = target
        t0 = time.perf_counter()
        writer = None
        try:
            _reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port), timeout=PROBE_TIMEOUT_S)
        except (OSError, asyncio.TimeoutError) as exc:
            return {"status": "unreachable", "target": f"{host}:{port}",
                    "error": type(exc).__name__, "checked_at": _now_iso()}
        finally:
            if writer is not None:
                writer.close()
        return {"status": "ok", "target": f"{host}:{port}",
                "rtt_ms": round((time.perf_counter() - t0) * 1000, 1),
                "checked_at": _now_iso()}

    # ── state bookkeeping ────────────────────────────────────────────────
    async def _running_instances(self, pool) -> list:
        rows = await pool.fetch(
            """
            SELECT i.id, i.public_host,
                   (SELECT dep.node_id FROM deployments dep
                     WHERE dep.instance_id = i.id
                     ORDER BY dep.started_at DESC LIMIT 1) AS node_id,
                   (SELECT d.domain FROM domains d WHERE d.instance_id = i.id
                     AND d.is_active = TRUE AND d.kind = 'path'
                     ORDER BY d.created_at DESC LIMIT 1) AS token
            FROM instances i WHERE i.status = 'running'
            """
        )
        return [{"id": str(r["id"]), "node_id": r["node_id"] or "local",
                 "token": r["token"], "public_host": (r["public_host"] or "").strip()}
                for r in rows]

    def _gc(self, running: list) -> None:
        live = {r["id"] for r in running}
        for iid in [k for k in self._states if k not in live]:
            self._states.pop(iid, None)

    def _record(self, iid: str, core: dict, public: dict | None) -> None:
        state = self._states.setdefault(
            iid, {"history": deque(maxlen=HISTORY_LEN), "consec_fail": 0,
                  "host_hint": "", "last": None, "checked_epoch": 0.0})
        ok = bool(core.get("ok"))
        state["history"].append({"t": round(time.time(), 1),
                                 "ok": ok,
                                 "rtt_ms": core.get("rtt_ms")})
        state["consec_fail"] = 0 if ok else state["consec_fail"] + 1
        state["checked_epoch"] = time.time()
        state["last"] = {"core": core, "public": public}
        self._states[iid] = state

    async def _probe_instance(self, row: dict, host_hint: str) -> None:
        core = await self._probe_core(row["id"], row["node_id"])
        state = self._states.get(row["id"]) or {}
        host = row["public_host"] or (state.get("host_hint") or "") or (host_hint or "")
        if host and state.get("host_hint"):
            state["host_hint"] = host_hint  # keep the freshest UI hint
        public = None
        if host and row["token"]:
            public = await self._probe_public(host, row["token"])
        self._record(row["id"], core, public)

    # ── main loop ───────────────────────────────────────────────────────
    async def _loop(self, pool) -> None:
        try:
            while True:
                try:
                    running = await self._running_instances(pool)
                except Exception as exc:  # DB gone: exit (lazy restart)
                    log.warning("health monitor: cannot list instances (%s) — stopping",
                                type(exc).__name__)
                    return
                self._gc(running)
                if not running:
                    self._idle_cycles += 1
                    if self._idle_cycles >= IDLE_CYCLES_BEFORE_EXIT:
                        log.info("health monitor: no running instances — idle exit")
                        return
                else:
                    self._idle_cycles = 0
                    batch = running[self._cursor:self._cursor + MAX_PER_CYCLE]
                    self._cursor = (self._cursor + len(batch)) % max(len(running), 1)
                    for row in batch:
                        try:
                            await self._probe_instance(row, "")
                        except Exception:
                            log.exception("health probe failed for %s", row["id"])
                try:
                    self._reality = await self._probe_reality()
                except Exception:
                    log.exception("reality probe failed")
                await asyncio.sleep(INTERVAL_S)
        except asyncio.CancelledError:
            pass
        finally:
            # only clear OUR slot — a newer restart may already own it
            current = asyncio.current_task()
            if self._task is None or self._task is current:
                self._task = None

    # ── public API ───────────────────────────────────────────────────────
    def remember_host_hint(self, instance_id: str, host: str) -> None:
        host = (host or "").strip()
        if not host:
            return
        if "://" in host:  # UI sent a full origin
            host = host.split("://", 1)[1]
        if host.startswith("[") and "]" in host:
            host = host.split("]", 1)[0] + "]"  # strip :port after a v6 literal
        elif host.count(":") == 1:
            host = host.rsplit(":", 1)[0]
        state = self._states.setdefault(
            instance_id, {"history": deque(maxlen=HISTORY_LEN), "consec_fail": 0,
                          "host_hint": "", "last": None, "checked_epoch": 0.0})
        state["host_hint"] = host

    async def snapshot(self, pool, instance_id: str, host_hint: str = "",
                      cached_only: bool = False) -> dict:
        """Health snapshot; probes inline when the state is cold or stale.

        ``cached_only=True`` never probes — it returns the last known state
        (the background loop refreshes it every cycle) or a no-data marker.
        Used by cheap dashboard polls so the overview can never trigger a
        probe storm.
        """
        await self.ensure_started(pool)
        if host_hint:
            self.remember_host_hint(instance_id, host_hint)
        state = self._states.get(instance_id)

        fresh = (state is not None and state.get("last") is not None
                 and time.time() - (state.get("checked_epoch") or 0) < INTERVAL_S)
        if not fresh and not cached_only:
            running = [r for r in await self._running_instances(pool)
                       if r["id"] == instance_id]
            if not running:
                return {"status": "no-endpoint",
                        "detail": "instance has no running endpoint to probe"}
            row = running[0]
            host = row["public_host"] or (state or {}).get("host_hint") or host_hint
            public = (await self._probe_public(host, row["token"])
                      if host and row["token"] else None)
            core = await self._probe_core(row["id"], row["node_id"])
            self._record(instance_id, core, public)
            state = self._states.get(instance_id)

        if state is None or not state.get("last"):
            return {"status": "no-data",
                    "detail": "health probe has not run yet — open the instance "
                              "page or wait for the next monitoring cycle"}

        core = (state or {}).get("last", {}).get("core") or {}
        public = (state or {}).get("last", {}).get("public")
        history = list((state or {}).get("history") or [])
        consec_fail = (state or {}).get("consec_fail", 0)

        if not core.get("ok"):
            status = "down" if consec_fail >= 2 else "degraded"
        elif core.get("rtt_ms", 0) > RTT_DEGRADED_MS:
            status = "degraded"
        elif public is not None and not public.get("ok"):
            status = "degraded"
        else:
            status = "healthy"

        return {
            "status": status,
            "core": core,
            "public_path": public,
            "reality": self._reality,
            "history": history,
            "interval_s": INTERVAL_S,
        }


monitor = _HealthMonitor()


async def health_snapshot(pool, instance_id: str, host_hint: str = "",
                          cached_only: bool = False) -> dict:
    return await monitor.snapshot(pool, instance_id, host_hint,
                                  cached_only=cached_only)

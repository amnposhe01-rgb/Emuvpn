"""Deployment pipeline with pluggable providers.

Providers:
* ``railway`` — one Railway service per EMUNEL instance (per-instance public
  domain via Railway's API, WebSocket-capable, TLS at the edge). Selected
  automatically when EMUNEL_RAILWAY_TOKEN + project/environment are configured.
* ``local``   — EMUNEL Worker on a node running instances as containers
  (Docker driver) or dev processes. Selected for self-hosted single-node.

Lifecycle (real transitions only — no simulated states):
QUEUED → PREPARING → BUILDING → STARTING → HEALTH_CHECK → RUNNING / FAILED
"""
from __future__ import annotations

import asyncio
import secrets
from datetime import datetime, timezone

import asyncpg
import httpx

from ..config import settings
from ..logging import get
from . import workers as worker_svc
from .railway import RailwayError, RailwayProvider

log = get("runtime", "emunel.console.deploy")

HEALTH_CHECK_ATTEMPTS = 30
HEALTH_CHECK_INTERVAL = 1.0
RAILWAY_POLL_ATTEMPTS = 90
RAILWAY_POLL_INTERVAL = 2.0


def railway_provider() -> RailwayProvider | None:
    try:
        return RailwayProvider.from_env()
    except RailwayError:
        return None


async def _log(pool: asyncpg.Pool, deployment_id: str, message: str, level: str = "info") -> None:
    await pool.execute(
        "INSERT INTO deployment_logs (deployment_id, ts, level, message) VALUES ($1, $2, $3, $4)",
        deployment_id, datetime.now(timezone.utc), level, message,
    )
    log.info("deploy[%s] %s", deployment_id[:8], message)


async def _set_deployment(pool: asyncpg.Pool, deployment_id: str, status: str,
                          error: str | None = None, finish: bool = False) -> None:
    if finish:
        row = await pool.fetchrow(
            "SELECT started_at FROM deployments WHERE id = $1", deployment_id
        )
        duration_ms = None
        if row is not None and row["started_at"] is not None:
            started = row["started_at"]
            if isinstance(started, str):
                started = datetime.fromisoformat(started)
            if started.tzinfo is None:
                started = started.replace(tzinfo=timezone.utc)
            duration_ms = int((datetime.now(timezone.utc) - started).total_seconds() * 1000)
        await pool.execute(
            "UPDATE deployments SET status = $2, error = $3, finished_at = $4, duration_ms = $5 "
            "WHERE id = $1",
            deployment_id, status, error, datetime.now(timezone.utc), duration_ms,
        )
    else:
        await pool.execute(
            "UPDATE deployments SET status = $2, error = $3 WHERE id = $1",
            deployment_id, status, error,
        )
    await pool.execute(
        "UPDATE instances SET status = $2, updated_at = $3 WHERE id = "
        "(SELECT instance_id FROM deployments WHERE id = $1)",
        deployment_id, status, datetime.now(timezone.utc),
    )


async def _set_instance(pool: asyncpg.Pool, instance_id: str, status: str) -> None:
    now_iso = datetime.now(timezone.utc)
    await pool.execute(
        "UPDATE instances SET status=$2, last_active_at=$3, updated_at=$3 WHERE id=$1",
        instance_id, status, now_iso,
    )


async def _instance_row(pool: asyncpg.Pool, instance_id: str) -> asyncpg.Record:
    return await pool.fetchrow(
        """
        SELECT i.id, i.slug, i.name, i.region, i.provider, i.provider_ref, i.core_api_token,
               c.core_version, c.cpu_limit, c.memory_mb, c.max_processes
        FROM instances i JOIN instance_configs c ON c.instance_id = i.id
        WHERE i.id = $1
        """,
        instance_id,
    )


async def deploy_instance(pool: asyncpg.Pool, instance_id: str, *, is_redeploy: bool = False) -> str:
    """Queue a deployment and run the pipeline as a background task."""
    from .gateway import invalidate_endpoint_cache

    invalidate_endpoint_cache(instance_id)
    row = await pool.fetchrow(
        "SELECT COALESCE(MAX(version), 0) + 1 AS v FROM deployments WHERE instance_id = $1",
        instance_id,
    )
    version = row["v"]
    inst = await _instance_row(pool, instance_id)
    if inst is None:
        raise ValueError("instance not found")

    deployment_id = str((await pool.fetchrow(
        """
        INSERT INTO deployments (id, instance_id, version, core_version, status, started_at)
        VALUES ($1, $2, $3, $4, 'queued', $5)
        RETURNING id
        """,
        secrets.token_hex(16), instance_id, version, inst["core_version"],
        datetime.now(timezone.utc),
    ))["id"])

    asyncio.create_task(_run_pipeline(pool, deployment_id, dict(inst), is_redeploy))
    return deployment_id


async def _run_pipeline(pool: asyncpg.Pool, deployment_id: str, inst: dict,
                        is_redeploy: bool) -> None:
    try:
        if inst.get("provider") == "railway" or railway_provider() is not None:
            await _pipeline_railway(pool, deployment_id, inst, is_redeploy)
        else:
            await _pipeline_local(pool, deployment_id, inst)
    except Exception as exc:  # final safety net
        log.exception("pipeline crashed: %s", exc)
        await _log(pool, deployment_id, f"Internal pipeline error: {exc}", "error")
        await _set_deployment(pool, deployment_id, "failed", error=str(exc)[:500], finish=True)
        await _set_instance(pool, inst["id"], "failed")


# ---------------------------------------------------------------------------
# Railway provider pipeline
# ---------------------------------------------------------------------------
async def _pipeline_railway(pool: asyncpg.Pool, deployment_id: str, inst: dict,
                            is_redeploy: bool) -> None:
    provider = railway_provider()
    if provider is None:
        raise RuntimeError("railway provider requested but not configured")
    instance_id = inst["id"]
    service_id = inst.get("provider_ref") or ""

    await _set_deployment(pool, deployment_id, "preparing")
    if not service_id:
        await _log(pool, deployment_id, "Creating Railway service…")
        service_id = await provider.create_service(f"emunel-inst-{instance_id[:8]}")
        await pool.execute(
            "UPDATE instances SET provider='railway', provider_ref=$2, updated_at=$3 WHERE id=$1",
            instance_id, service_id, datetime.now(timezone.utc),
        )
    else:
        await _log(pool, deployment_id, f"Reusing Railway service {service_id[:12]}…")

    # Domain: reuse the active generated domain, or create one.
    domain_row = await pool.fetchrow(
        "SELECT id, domain, provider_ref FROM domains WHERE instance_id=$1 AND is_custom=FALSE "
        "ORDER BY created_at DESC LIMIT 1",
        instance_id,
    )
    if domain_row is None:
        await _log(pool, deployment_id, "Generating public domain…")
        dom = await provider.create_domain(service_id)
        await pool.execute(
            """
            INSERT INTO domains (id, instance_id, domain, provider_ref, tls, created_at)
            VALUES ($4, $1, $2, $3, TRUE, $5)
            """,
            instance_id, dom["domain"], dom["id"], secrets.token_hex(16),
            datetime.now(timezone.utc),
        )
        domain = dom["domain"]
    else:
        domain = domain_row["domain"]

    # Configure source, health check and secrets (skipDeploys — we deploy explicitly).
    await _set_deployment(pool, deployment_id, "building")
    await _log(pool, deployment_id, f"Configuring {provider.core_image}…")
    await provider.configure_service(service_id, inst["core_api_token"], domain)

    await _set_deployment(pool, deployment_id, "starting")
    await _log(pool, deployment_id, "Triggering Railway deployment…")
    if is_redeploy and inst.get("provider_ref"):
        await provider.restart_service(service_id)
    else:
        await provider.start_service(service_id)

    # Wait for Railway to report the deployment healthy.
    for attempt in range(1, RAILWAY_POLL_ATTEMPTS + 1):
        await asyncio.sleep(RAILWAY_POLL_INTERVAL)
        dep = await provider.latest_deployment(service_id)
        if dep is None:
            continue
        status = STATUS_MAP.get(dep.get("status"), "starting")
        if status == "running":
            break
        if status in ("failed", "stopped"):
            logs = await provider.deployment_logs(dep["id"], 40)
            tail = " | ".join(logs[-5:])
            raise RuntimeError(f"railway deployment {dep['status']}: {tail[:400]}")
        if attempt % 5 == 0:
            await _log(pool, deployment_id, f"railway status: {dep['status']}")

    # Real end-to-end health check through Railway's public edge.
    await _set_deployment(pool, deployment_id, "health_check")
    await _log(pool, deployment_id, "Health checking public endpoint…")
    healthy = False
    async with httpx.AsyncClient(timeout=5.0) as client:
        for attempt in range(1, HEALTH_CHECK_ATTEMPTS + 1):
            try:
                resp = await client.get(f"https://{domain}/health")
                if resp.status_code == 200:
                    healthy = True
                    await _log(pool, deployment_id, f"Healthy after {attempt} probe(s)")
                    break
            except (httpx.HTTPError, OSError):
                pass
            await asyncio.sleep(HEALTH_CHECK_INTERVAL)
    if not healthy:
        raise RuntimeError("public health check failed after deployment reported success")

    # Provision the instance's default proxy link so the user gets a
    # working config immediately (VLESS/Trojan/SS depending on protocol).
    await _provision_default_link(pool, deployment_id, instance_id)

    await _set_deployment(pool, deployment_id, "running", finish=True)
    await _set_instance(pool, instance_id, "running")
    await _log(pool, deployment_id, "Instance is running — config ready", "ok")


# ---------------------------------------------------------------------------
# Local worker pipeline
# ---------------------------------------------------------------------------
async def _pipeline_local(pool: asyncpg.Pool, deployment_id: str, inst: dict) -> None:
    instance_id = inst["id"]
    await _set_deployment(pool, deployment_id, "preparing")
    await _log(pool, deployment_id, "Selecting worker node…")
    picked = await worker_svc.pick_worker(pool, inst.get("region"))
    if picked is None:
        raise RuntimeError("no online worker available")
    node_id, node_url = picked
    await pool.execute("UPDATE deployments SET node_id = $2 WHERE id = $1", deployment_id, node_id)
    await _log(pool, deployment_id, f"Worker node selected: {node_id}")

    await _set_deployment(pool, deployment_id, "building")
    await _log(pool, deployment_id, f"Preparing EMUNEL Core {inst['core_version']}…")

    await _set_deployment(pool, deployment_id, "starting")
    launch = await worker_svc.worker_call(
        node_url, "POST", f"/worker/api/instances/{instance_id}/launch",
        json_body={
            "deployment_id": deployment_id,
            "core_version": inst["core_version"],
            "core_api_token": inst["core_api_token"],
            "cpu_limit": inst["cpu_limit"],
            "memory_mb": inst["memory_mb"],
            "max_processes": inst["max_processes"],
        },
    )
    await _log(pool, deployment_id, f"Launched on {launch.get('driver')} (port {launch.get('port')})")

    await _set_deployment(pool, deployment_id, "health_check")
    await _log(pool, deployment_id, "Running health checks…")
    healthy = False
    for attempt in range(1, HEALTH_CHECK_ATTEMPTS + 1):
        await asyncio.sleep(HEALTH_CHECK_INTERVAL)
        try:
            status = await worker_svc.worker_call(
                node_url, "GET", f"/worker/api/instances/{instance_id}/status", timeout=10.0
            )
        except worker_svc.WorkerError as exc:
            await _log(pool, deployment_id, f"probe {attempt}: {exc}", "warn")
            continue
        if status.get("healthy"):
            healthy = True
            await _log(pool, deployment_id, f"Healthy after {attempt} probe(s)")
            break
        if not status.get("running"):
            raise RuntimeError("instance process exited during health check")
    if not healthy:
        raise RuntimeError("health check did not pass in time")

    await _provision_default_link(pool, deployment_id, instance_id)

    await _set_deployment(pool, deployment_id, "running", finish=True)
    await _set_instance(pool, instance_id, "running")
    await _log(pool, deployment_id, "Instance is running — config ready", "ok")


async def _provision_default_link(pool: asyncpg.Pool, deployment_id: str,
                                  instance_id: str) -> None:
    """Create the default proxy links inside the freshly deployed Core and
    record them. Idempotent: skips when the instance already has a link.
    The wizard's traffic policy (quota / expiry / speed / IP cap) is applied
    to every provisioned link for real."""
    try:
        from ..config import settings as _settings

        row = await pool.fetchrow(
            "SELECT core_api_token, name, protocol FROM instances i "
            "JOIN instance_configs c ON c.instance_id = i.id WHERE i.id = $1",
            instance_id,
        )
        existing = await pool.fetchval(
            "SELECT COUNT(*) FROM instance_links WHERE instance_id = $1", instance_id
        )
        if row is None or existing:
            # Still reconcile: a redeploy may have lost the Core's state file —
            # re-push the Console DB policies so configs survive with the
            # same UUIDs, quotas and counters.
            await _reconcile_links(pool, deployment_id, instance_id)
            return
        dep = await pool.fetchrow(
            "SELECT node_id FROM deployments WHERE id = $1", deployment_id
        )
        node_url = worker_svc.worker_url_for(
            (dep["node_id"] if dep else None) or _settings.default_worker_node
        )
        cfg_row = await pool.fetchrow(
            "SELECT protocols, link_policy FROM instance_configs WHERE instance_id = $1",
            instance_id,
        )
        selected = (cfg_row["protocols"].split(",") if cfg_row and cfg_row["protocols"] else None) \
            or [row["protocol"] or "vless-ws"]
        pretty_map = {"vless-ws": "VLESS", "trojan-ws": "Trojan",
                      "shadowsocks": "Shadowsocks", "xhttp-packet-up": "xHTTP",
                      "xhttp-stream-up": "xHTTP",
                      "trojan-xhttp-packet-up": "Trojan xHTTP packet-up",
                      "trojan-xhttp-stream-up": "Trojan xHTTP stream-up",
                      "vmess-ws": "VMess"}
        wanted = [(p, pretty_map.get(p, p)) for p in selected]
        # Wizard traffic policy: {limit_bytes, expires_at, speed_limit_bytes, ip_limit}
        policy = {}
        if cfg_row and cfg_row["link_policy"]:
            try:
                import json as _json

                policy = _json.loads(cfg_row["link_policy"]) or {}
            except (ValueError, TypeError):
                policy = {}
        created = 0
        skipped = []
        async with httpx.AsyncClient(timeout=30) as client:
            for proto, pretty in wanted:
                resp = await client.post(
                    f"{node_url.rstrip('/')}/worker/api/instances/{instance_id}"
                    f"/proxy/core/api/links",
                    json={"label": f"{row['name']} · {pretty}", "protocol": proto,
                          "limit_bytes": int(policy.get("limit_bytes") or 0),
                          "expires_at": policy.get("expires_at"),
                          "speed_limit_bytes": int(policy.get("speed_limit_bytes") or 0),
                          "ip_limit": int(policy.get("ip_limit") or 0)},
                    headers={"Authorization": f"Bearer {_settings.worker_token}",
                             "Content-Type": "application/json"},
                )
                if resp.status_code >= 400:
                    # One unprovisionable protocol (e.g. VMess without an
                    # operator-installed Xray runtime) must not fail a deploy
                    # whose other protocols are working.
                    detail = str(resp.json().get("detail") or resp.text)[:200]
                    skipped.append(f"{pretty}: {detail}")
                    await _log(pool, deployment_id,
                               f"Skipped {pretty} link — {detail}", "warn")
                    continue
                link_uuid = resp.json()["uuid"]
                # `active` is BOOLEAN on PostgreSQL and INTEGER on SQLite —
                # the TRUE keyword is valid in BOTH dialects (SQLite >= 3.23),
                # a bare 1 crashes asyncpg with DatatypeMismatchError and
                # fails the whole deployment at this final stage.
                await pool.execute(
                    "INSERT INTO instance_links (id, instance_id, link_uuid, label, protocol, "
                    "limit_bytes, expires_at, speed_limit_bytes, ip_limit, active, used_cache, "
                    "used_at, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, TRUE, 0, NULL, $10)",
                    secrets.token_hex(16), instance_id, link_uuid,
                    f"{row['name']} · {pretty}", proto,
                    int(policy.get("limit_bytes") or 0) or None,
                    policy.get("expires_at"),
                    int(policy.get("speed_limit_bytes") or 0) or None,
                    int(policy.get("ip_limit") or 0) or None,
                    datetime.now(timezone.utc),
                )
                created += 1
        if created:
            await _log(pool, deployment_id,
                       f"Provisioned {created} links"
                       + (f" ({len(skipped)} skipped)" if skipped else ""), "ok")
        elif skipped:
            raise RuntimeError("no protocol could be provisioned; see deployment logs")
        await _reconcile_links(pool, deployment_id, instance_id)
    except Exception as exc:
        await _log(pool, deployment_id, f"link provisioning failed: {exc}", "error")
        raise RuntimeError("selected protocol could not be provisioned; check Core runtime configuration") from exc


async def _reconcile_links(pool: asyncpg.Pool, deployment_id: str,
                          instance_id: str) -> None:
    """After health: make the Core match the Console DB — restore links the
    Core lost (fresh state file / new service) and re-apply drifted policies.
    Also pushes the instance volume cap so relay-time enforcement starts
    with the deployment, not only on the next volume loop cycle.
    Best-effort; never fails a healthy deployment."""
    try:
        from . import links as links_svc

        await links_svc.reconcile_after_deploy(pool, instance_id, None)
    except Exception as exc:
        await _log(pool, deployment_id, f"link reconcile skipped: {exc}", "warn")
    try:
        from . import volume as volume_svc

        if await volume_svc.push_core_cap(pool, instance_id):
            await _log(pool, deployment_id, "volume cap pushed to Core (relay-time)", "ok")
    except Exception as exc:
        await _log(pool, deployment_id, f"volume cap push skipped: {exc}", "warn")


# ---------------------------------------------------------------------------
# Control operations (provider-aware)
# ---------------------------------------------------------------------------
async def _provider_for_instance(pool: asyncpg.Pool, instance_id: str) -> tuple[str, asyncpg.Record]:
    inst = await _instance_row(pool, instance_id)
    if inst is None:
        raise ValueError("instance not found")
    if inst["provider"] == "railway" or (inst["provider"] is None and railway_provider() is not None):
        return "railway", inst
    return "local", inst


async def stop_instance(pool: asyncpg.Pool, instance_id: str) -> None:
    from .gateway import invalidate_endpoint_cache

    invalidate_endpoint_cache(instance_id)
    kind, inst = await _provider_for_instance(pool, instance_id)
    if kind == "railway":
        provider = railway_provider()
        if inst["provider_ref"] and provider:
            await provider.stop_service(inst["provider_ref"])
    else:
        inst2 = await pool.fetchrow(
            """
            SELECT d.node_id FROM deployments d WHERE instance_id = $1
            ORDER BY started_at DESC LIMIT 1
            """,
            instance_id,
        )
        node_url = worker_svc.worker_url_for((inst2["node_id"] if inst2 else None) or settings.default_worker_node)
        await worker_svc.worker_call(node_url, "POST", f"/worker/api/instances/{instance_id}/stop")
    await pool.execute(
        "UPDATE instances SET status='stopped', updated_at=$2 WHERE id=$1",
        instance_id, datetime.now(timezone.utc),
    )


async def restart_instance(pool: asyncpg.Pool, instance_id: str) -> None:
    from .gateway import invalidate_endpoint_cache

    invalidate_endpoint_cache(instance_id)
    kind, inst = await _provider_for_instance(pool, instance_id)
    if kind == "railway":
        provider = railway_provider()
        if inst["provider_ref"] and provider:
            await provider.restart_service(inst["provider_ref"])
        await pool.execute(
            "UPDATE instances SET status='starting', updated_at=$2 WHERE id=$1",
            instance_id, datetime.now(timezone.utc),
        )
    else:
        await deploy_instance(pool, instance_id, is_redeploy=True)


async def delete_from_provider(pool: asyncpg.Pool, instance_id: str) -> None:
    from .gateway import invalidate_endpoint_cache

    invalidate_endpoint_cache(instance_id)
    kind, inst = await _provider_for_instance(pool, instance_id)
    if kind == "railway":
        provider = railway_provider()
        if inst["provider_ref"] and provider:
            try:
                await provider.delete_service(inst["provider_ref"])
            except RailwayError as exc:
                log.warning("railway service delete failed for %s: %s", instance_id, exc)
    else:
        inst2 = await pool.fetchrow(
            "SELECT node_id FROM deployments WHERE instance_id = $1 ORDER BY started_at DESC LIMIT 1",
            instance_id,
        )
        if inst2 and inst2["node_id"]:
            node_url = worker_svc.worker_url_for(inst2["node_id"])
            try:
                await worker_svc.worker_call(
                    node_url, "POST", f"/worker/api/instances/{instance_id}/remove", timeout=20.0
                )
            except worker_svc.WorkerError as exc:
                log.warning("worker remove failed for %s: %s", instance_id, exc)

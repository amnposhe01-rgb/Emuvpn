"""Iran-tuned client config generation (console layer — Core is untouched).

October 2026 context (why this module exists): the Iranian censor operates a
whitelist/tiered national network with throttled international bandwidth,
datacenter-IP throttling and TLS-DPI that resets detected VPN handshakes
(TCP RST injection during/after ClientHello). Share links that work fine from
an unfiltered network "give no ping" from Iran because the TLS handshake is
inspected and killed before the tunnel ever establishes.

The countermeasure that keeps working for TLS-transported proxies is
ClientHello FRAGMENTATION on the CLIENT side (Xray freedom outbound with
``fragment`` chained via ``sockopt.dialerProxy``): the ClientHello is split
into randomly-sized pieces so the DPI never sees a whole SNI/extension
block to match. This module turns a normal share link into a complete,
importable Xray client config with that chain pre-wired.

REALITY links skip the fragment chain on purpose: REALITY borrows a real
domestic TLS handshake (blubank.com / divar.ir), which the censor cannot
reset without breaking the bank — fragmenting it would only add latency.

Everything here is pure client-side output: no Core file, protocol or
network semantic is modified.
"""
from __future__ import annotations

import base64
import json
import os
from urllib.parse import parse_qs, unquote, urlparse

# Fragment knobs (operator-tunable, defaults match the community-proven
# tlshi 100-200 / 10-20 values that defeat the current Iranian DPI).
FRAGMENT_PACKETS = os.environ.get("EMUNEL_FRAGMENT_PACKETS", "tlshi").strip() or "tlshi"
FRAGMENT_LENGTH = os.environ.get("EMUNEL_FRAGMENT_LENGTH", "100-200").strip() or "100-200"
FRAGMENT_INTERVAL = os.environ.get("EMUNEL_FRAGMENT_INTERVAL", "10-20").strip() or "10-20"

# uTLS fingerprint rewrite for ?tune=iran — rotates per connection so the
# censor cannot build a fingerprint blocklist (Xray >= v24.12; harmless
# keyword for older clients which fall back to their default).
TUNED_FINGERPRINT = os.environ.get("EMUNEL_TUNED_FINGERPRINT", "randomized").strip() or "randomized"

# TCP keepalive for every generated client config (Xray sockopt fields
# ``tcpKeepAliveIdle`` / ``tcpKeepAliveInterval``, seconds — verified
# against Xray-core v26.3.27 ``infra/conf/transport_internet.go``). Iranian
# mobile NATs drop idle mappings aggressively; keepalive probes every few
# seconds keep the binding warm so a resumed page load skips a full
# TLS+fragment re-handshake — directly better perceived ping.
TCP_KEEPALIVE_IDLE = max(0, int(os.environ.get("EMUNEL_TCP_KEEPALIVE_IDLE", "15") or 0))
TCP_KEEPALIVE_INTERVAL = max(0, int(os.environ.get("EMUNEL_TCP_KEEPALIVE_INTERVAL", "5") or 0))


class UnsupportedConfig(ValueError):
    """The share link cannot be turned into an Iran-tuned Xray config."""


def _q1(q: dict, key: str, default: str = "") -> str:
    v = q.get(key)
    return v[0] if v else default


def parse_share_url(url: str) -> dict:
    """vless/trojan/vmess share URL -> normalized transport description."""
    url = (url or "").strip()
    if not url:
        raise UnsupportedConfig("empty share link")
    scheme = urlparse(url).scheme.lower()

    if scheme == "vmess":
        raw = url[8:]
        try:
            data = json.loads(base64.b64decode(raw + "=" * (-len(raw) % 4)))
        except Exception as exc:
            raise UnsupportedConfig("vmess link is not valid base64 JSON") from exc
        return {
            "protocol": "vmess",
            "uuid": data.get("id", ""),
            "host": data.get("add", ""),
            "port": int(data.get("port") or 443),
            "network": data.get("net", "ws"),
            "security": "tls" if data.get("tls") == "tls" else "none",
            "sni": data.get("sni") or data.get("add") or "",
            "host_header": data.get("host") or data.get("add") or "",
            "path": data.get("path") or "/",
            "fingerprint": data.get("fp") or "chrome",
            "alpn": ["http/1.1"],
            "flow": "",
            "mode": "",
            "remark": data.get("ps") or "EMUNEL",
        }

    if scheme not in ("vless", "trojan"):
        raise UnsupportedConfig(
            "only vless:// trojan:// and vmess:// links can be Iran-tuned; "
            "Shadowsocks has no TLS handshake to fragment")

    u = urlparse(url)
    q = {k: v for k, v in parse_qs(u.query).items()}
    security = _q1(q, "security", "tls") or "tls"
    network = _q1(q, "type", "ws") or "ws"
    if network == "tcp":
        network = "raw"
    alpn_raw = unquote(_q1(q, "alpn", "http/1.1"))
    return {
        "protocol": scheme,
        "uuid": unquote(u.username or ""),
        "host": u.hostname or "",
        "port": u.port or 443,
        "network": network,
        "security": security,
        "sni": _q1(q, "sni") or _q1(q, "host") or (u.hostname or ""),
        "host_header": _q1(q, "host") or (u.hostname or ""),
        "path": unquote(_q1(q, "path", "/")),
        "fingerprint": _q1(q, "fp", "chrome") or "chrome",
        "alpn": [a for a in alpn_raw.split(",") if a] or ["http/1.1"],
        "flow": _q1(q, "flow"),
        "mode": _q1(q, "mode"),
        "public_key": _q1(q, "pbk"),
        "short_id": _q1(q, "sid"),
        "spider_x": unquote(_q1(q, "spx", "/")),
        "grpc_service": _q1(q, "serviceName"),
        "remark": unquote(u.fragment) or "EMUNEL",
    }


def _tcp_keepalive_sockopt() -> dict:
    opt: dict = {}
    if TCP_KEEPALIVE_IDLE > 0:
        opt["tcpKeepAliveIdle"] = TCP_KEEPALIVE_IDLE
    if TCP_KEEPALIVE_INTERVAL > 0:
        opt["tcpKeepAliveInterval"] = TCP_KEEPALIVE_INTERVAL
    return opt


def _fragment_outbound() -> dict:
    out: dict = {
        "tag": "fragment-out",
        "protocol": "freedom",
        "settings": {
            "domainStrategy": "AsIs",
            "fragment": {
                "packets": FRAGMENT_PACKETS,
                "length": FRAGMENT_LENGTH,
                "interval": FRAGMENT_INTERVAL,
            },
        },
    }
    # The fragment dialer performs the real TCP dial (dialerProxy chain),
    # so it carries the keepalive too — probes flow on the same socket the
    # tunnel lives on.
    opt = _tcp_keepalive_sockopt()
    if opt:
        out["streamSettings"] = {"sockopt": opt}
    return out


def _stream_settings(p: dict, *, chain_fragment: bool) -> dict:
    stream: dict = {"network": p["network"], "security": p["security"]}
    if p["security"] == "reality":
        reality = {
            "serverName": p["sni"],
            "fingerprint": p["fingerprint"],
            "shortId": p["short_id"],
            "spiderX": p["spider_x"],
        }
        if p["public_key"]:
            # modern field name first, legacy kept for older cores
            reality["password"] = p["public_key"]
            reality["publicKey"] = p["public_key"]
        stream["realitySettings"] = reality
    else:
        stream["tlsSettings"] = {
            "serverName": p["sni"],
            "fingerprint": p["fingerprint"],
            "alpn": p["alpn"],
            "allowInsecure": False,
        }
    if p["network"] == "ws":
        stream["wsSettings"] = {
            "path": p["path"],
            "headers": {"Host": p["host_header"] or p["host"]},
        }
    elif p["network"] == "xhttp":
        xs: dict = {
            "path": p["path"],
            "host": p["host_header"] or p["host"],
        }
        if p["mode"]:
            xs["mode"] = p["mode"]
        stream["xhttpSettings"] = xs
    elif p["network"] == "grpc":
        stream["grpcSettings"] = {"serviceName": p["grpc_service"] or "emunel"}
    else:  # raw
        stream["rawSettings"] = {"header": {"type": "none"}}
    # TCP keepalive on the proxy outbound as well (covers REALITY and every
    # transport); stacks with the fragment dialer's own sockopt above.
    opt = _tcp_keepalive_sockopt()
    if chain_fragment:
        opt["dialerProxy"] = "fragment-out"
    if opt:
        stream["sockopt"] = opt
    return stream


def build_xray_fragment_config(share_url: str) -> dict:
    """Share link -> complete Xray client config with a fragment dialer.

    vless/trojan/vmess over TLS (ws / xhttp / grpc) get the
    ``proxy -> fragment-out (freedom + fragment)`` chain; REALITY links are
    emitted without fragmentation (borrowed domestic handshake needs none).
    """
    p = parse_share_url(share_url)

    if p["security"] not in ("tls", "reality"):
        raise UnsupportedConfig(
            "this config has no TLS layer to fragment — use a ws/xhttp "
            "VLESS/Trojan config or a REALITY config")

    stream = _stream_settings(p, chain_fragment=p["security"] == "tls")

    if p["protocol"] == "trojan":
        settings: dict = {
            "servers": [{
                "address": p["host"],
                "port": p["port"],
                "password": p["uuid"],
            }],
        }
    else:
        user: dict = {"id": p["uuid"]}
        if p["protocol"] == "vless":
            user["encryption"] = "none"
            if p["flow"]:
                user["flow"] = p["flow"]
        else:  # vmess
            user["alterId"] = 0
            user["security"] = "auto"
        settings = {"vnext": [{"address": p["host"], "port": p["port"],
                                "users": [user]}]}

    outbound: dict = {
        "tag": "proxy",
        "protocol": p["protocol"],
        "settings": settings,
        "streamSettings": stream,
        "mux": {"enabled": False, "concurrency": -1},
    }

    outbounds = [outbound]
    if p["security"] == "tls":
        outbounds.append(_fragment_outbound())
    outbounds.append({"tag": "direct", "protocol": "freedom",
                      "settings": {"domainStrategy": "UseIP"}})
    outbounds.append({"tag": "block", "protocol": "blackhole", "settings": {}})

    return {
        "log": {"loglevel": "warning"},
        "inbounds": [{
            "tag": "socks-in",
            "listen": "127.0.0.1",
            "port": 10808,
            "protocol": "socks",
            "settings": {"auth": "noauth", "udp": True, "userLevel": 0},
            "sniffing": {"enabled": True, "destOverride": ["http", "tls"],
                         "routeOnly": True},
        }],
        "outbounds": outbounds,
        "routing": {
            "domainStrategy": "IPIfNonMatch",
            "rules": [
                # domestic traffic never pays the tunnel (also keeps banks
                # working while the VPN is up)
                {"type": "field", "ip": ["geoip:private", "geoip:ir"],
                 "outboundTag": "direct"},
                {"type": "field", "network": "tcp,udp", "outboundTag": "proxy"},
            ],
        },
    }


def iran_tune_url(url: str) -> str:
    """Rewrite a share link's uTLS fingerprint (fp=randomized).

    Rotation defeats fingerprint blocklists; only the fp query value is
    touched, everything else stays byte-identical.
    """
    url = (url or "").strip()
    if "fp=" not in url:
        return url
    from urllib.parse import quote as _q

    head, _, frag = url.partition("#")
    if "fp=" in head:
        # replace every fp=... value in the query part only
        base, sep, query = head.partition("?")
        if sep:
            parts = []
            for kv in query.split("&"):
                if kv.startswith("fp="):
                    kv = "fp=" + _q(TUNED_FINGERPRINT, safe="")
                parts.append(kv)
            head = base + "?" + "&".join(parts)
    return head + ("#" + frag if frag else "")


def reality_public_target() -> tuple[str, int] | None:
    """(host, port) of the panel's REALITY TCP route, when configured."""
    raw = os.environ.get("REALITY_PUBLIC_HOST", "").strip()
    if not raw:
        return None
    host = raw
    port = 0
    if ":" in raw:
        host, _, port_s = raw.rpartition(":")
        if port_s.isdigit():
            port = int(port_s)
    if not port:
        p = os.environ.get("EMUNEL_REALITY_PUBLIC_PORT") or \
            os.environ.get("EMUNEL_REALITY_LISTEN_PORT") or "8443"
        port = int(p) if str(p).isdigit() else 8443
    return host, port

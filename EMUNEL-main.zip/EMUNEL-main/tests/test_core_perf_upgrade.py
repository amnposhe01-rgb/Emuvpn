"""v1.6.0 performance/quality upgrade regressions.

Covers the four surgical upgrades:
  C1  xHTTP downlink liveness — an open GET keeps the session alive
      (Xray-core semantics; Core-side root fix for the periodic cut).
  C2  downlink buffer ceiling — 256KB chunks x 64-entry queue = 16MB cap.
  C3  kernel TCP autotuning — static SO_SNDBUF/RCVBUF only on opt-in.
  P1  selective gzip — panel/API compressed, /i/* tunnel paths untouched.
  P2  cached-only health reads — dashboard polls can never probe.
"""
import asyncio
import gzip
import hashlib
import os
import socket
import sys
import tempfile
import types
from pathlib import Path

import httpx
import pytest
import uvicorn

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "core"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "console" / "api"))

from emunel_core.app import Core
from emunel_core.config import CoreConfig
from emunel_core.links import generate_share_link
from emunel_core.relay import xhttp as xhttp_mod
from emunel_core.relay.base import tune_socket
from emunel_core.state import Link

UUID = "123e4567-e89b-12d3-a456-426614174000"


# ── C2: constants / queue bound ─────────────────────────────────────────────

def test_downlink_buffer_ceiling_constants():
    assert xhttp_mod.XHTTP_BUF == 256 * 1024
    assert xhttp_mod.DOWNLINK_QUEUE_MAX == 64
    # hard ceiling per session = 16MB (was 512 entries x up to 1MB = 512MB)
    assert xhttp_mod.XHTTP_BUF * xhttp_mod.DOWNLINK_QUEUE_MAX == 16 * 1024 * 1024


def test_env_int_clamps():
    assert xhttp_mod._env_int("EMUNEL_XHTTP_IDLE", 30, 5, 3600) == 30
    assert xhttp_mod._env_int("EMUNEL_XHTTP_IDLE", 30, 5, 3600) == 30
    os.environ["EMUNEL_XHTTP_IDLE"] = "3"       # below lo -> clamped
    try:
        assert xhttp_mod._env_int("EMUNEL_XHTTP_IDLE", 30, 5, 3600) == 5
    finally:
        del os.environ["EMUNEL_XHTTP_IDLE"]
    os.environ["EMUNEL_XHTTP_IDLE"] = "999999"  # above hi -> clamped
    try:
        assert xhttp_mod._env_int("EMUNEL_XHTTP_IDLE", 30, 5, 3600) == 3600
    finally:
        del os.environ["EMUNEL_XHTTP_IDLE"]
    os.environ["EMUNEL_XHTTP_IDLE"] = "not-a-number"
    try:
        assert xhttp_mod._env_int("EMUNEL_XHTTP_IDLE", 30, 5, 3600) == 30
    finally:
        del os.environ["EMUNEL_XHTTP_IDLE"]


def test_engine_reads_env_timeouts(monkeypatch):
    monkeypatch.setenv("EMUNEL_XHTTP_IDLE_ACTIVE", "45")
    monkeypatch.setenv("EMUNEL_XHTTP_IDLE", "20")
    engine = xhttp_mod.XHttpEngine(types.SimpleNamespace(), prefix="/xhttp-test")
    assert engine.idle_timeout_active == 45
    assert engine.idle_timeout == 20
    assert engine.touch_interval == xhttp_mod.DOWNLINK_TOUCH_INTERVAL


# ── C1: downlink liveness (the periodic-cut root fix) ────────────────────────

def test_open_get_keeps_session_alive(monkeypatch):
    """A quiet-but-open xHTTP tunnel must survive past idle_timeout_active.

    With the fix, the downlink generator touches last_seen every
    touch_interval while the GET is held open. The engine's runtime knobs
    (instance attributes) are tuned so the reaper runs 10x faster than the
    idle window here — a session without the fix is reaped in ~2s.
    """
    monkeypatch.setattr(xhttp_mod, "REAPER_INTERVAL", 0.2)
    asyncio.run(_open_get_liveness())


async def _open_get_liveness():
    async def echo(reader, writer):
        try:
            while data := await reader.read(65536):
                writer.write(data)
                await writer.drain()
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except (ConnectionResetError, OSError):
                pass

    echo_server = await asyncio.start_server(echo, "127.0.0.1", 0)
    echo_port = echo_server.sockets[0].getsockname()[1]
    with tempfile.TemporaryDirectory() as tmp:
        core = Core(CoreConfig(state_path=str(Path(tmp) / "state.json"), log_level="error"))
        core._schedule_save = lambda: None
        core.ctx.save_hook = lambda: None
        # fast liveness knobs (the env parser is integer-only by design —
        # instance attributes give sub-second precision for the test)
        core.trojan_xhttp.idle_timeout_active = 2
        core.trojan_xhttp.idle_timeout = 2
        core.trojan_xhttp.touch_interval = 0.5
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        sock.listen()
        port = sock.getsockname()[1]
        import uvicorn
        server = uvicorn.Server(uvicorn.Config(core.app, lifespan="off", log_level="error",
                                              timeout_graceful_shutdown=2))
        task = asyncio.create_task(server.serve(sockets=[sock]))
        try:
            async with asyncio.timeout(10):
                while not server.started:
                    await asyncio.sleep(0.01)
            link = Link(UUID, "test", "trojan-xhttp-stream-up")
            await core.links.add(link)
            url = generate_share_link(link, "example.test")
            from urllib.parse import urlsplit, parse_qs
            path = parse_qs(urlsplit(url).query)["path"][0] + "/liveness-sess"
            handshake = (hashlib.sha224(UUID.encode()).hexdigest().encode()
                         + b"\r\n\x01\x01\x7f\x00\x00\x01"
                         + echo_port.to_bytes(2, "big") + b"\r\n")
            async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{port}", trust_env=False,
                                         timeout=10) as client:
                # open the downlink GET first — its mere existence must keep
                # the session alive below
                get_cm = client.stream("GET", path)
                down = await get_cm.__aenter__()
                try:
                    assert down.status_code == 200
                    resp = await client.post(path, content=handshake)
                    assert resp.status_code == 200, resp.text

                    sess = core.trojan_xhttp.sessions[(UUID, "liveness-sess")]
                    assert sess["tcp_open"] is True
                    assert sess["down_q"].maxsize == xhttp_mod.DOWNLINK_QUEUE_MAX

                    # 3s of total silence — 1.5x the idle window, reaper
                    # has run ~15 times. Without the liveness touch the
                    # session is gone here (that WAS the minute-cut bug).
                    await asyncio.sleep(3.0)
                    assert (UUID, "liveness-sess") in core.trojan_xhttp.sessions, \
                        "session reaped while its GET was open (regression of the periodic-cut fix)"
                    # the touch itself must be the writer keeping it fresh
                    # (no traffic flowed; idle never crossed the window)
                    import time as _time
                    assert _time.time() - sess["last_seen"] < 1.0, \
                        "last_seen went stale despite the open GET (touch not firing)"

                    # the session must be FUNCTIONALLY alive: data still relays
                    payload = b"still-alive-after-idle"
                    resp = await client.post(path, content=payload)
                    assert resp.status_code == 200
                    received = b""
                    async for data in down.aiter_bytes():
                        received += data
                        if len(received) >= len(payload):
                            break
                    assert received == payload
                finally:
                    await get_cm.__aexit__(None, None, None)

                # GET closed + no uplink -> the touch stops, the reaper
                # must collect the session within the idle window
                await asyncio.sleep(3.2)
                assert (UUID, "liveness-sess") not in core.trojan_xhttp.sessions, \
                    "session leaked after GET closed and idle window passed"
        finally:
            for uuid, sid in list(core.trojan_xhttp.sessions):
                await core.trojan_xhttp.teardown(uuid, sid, "test shutdown")
            await core.vmess_runtime.close()
            server.should_exit = True
            await asyncio.wait_for(task, 5)
            sock.close()
            echo_server.close()
            await echo_server.wait_closed()


# ── C3: kernel TCP autotuning opt-in ────────────────────────────────────────

class _RecSock:
    def __init__(self):
        self.calls = []

    def setsockopt(self, level, opt, val):
        self.calls.append((level, opt, val))


def _fake_writer(rec):
    return types.SimpleNamespace(
        transport=types.SimpleNamespace(get_extra_info=lambda name: rec if name == "socket" else None)
    )


def test_tune_socket_autotune_default(monkeypatch):
    monkeypatch.delenv("EMUNEL_TCP_STATIC_BUF", raising=False)
    rec = _RecSock()
    tune_socket(_fake_writer(rec))
    opts = {(level, opt) for level, opt, _ in rec.calls}
    assert (socket.IPPROTO_TCP, socket.TCP_NODELAY) in opts
    assert (socket.SOL_SOCKET, socket.SO_SNDBUF) not in opts, \
        "static SO_SNDBUF disables kernel autotuning — must be opt-in only"
    assert (socket.SOL_SOCKET, socket.SO_RCVBUF) not in opts


@pytest.mark.parametrize("flag", ["1", "true", "yes"])
def test_tune_socket_static_optin(monkeypatch, flag):
    monkeypatch.setenv("EMUNEL_TCP_STATIC_BUF", flag)
    rec = _RecSock()
    tune_socket(_fake_writer(rec), sock_buf=262144)
    opts = {(level, opt): val for level, opt, val in rec.calls}
    assert opts.get((socket.SOL_SOCKET, socket.SO_SNDBUF)) == 262144
    assert opts.get((socket.SOL_SOCKET, socket.SO_RCVBUF)) == 262144


def test_tune_socket_static_rejects_garbage(monkeypatch):
    monkeypatch.setenv("EMUNEL_TCP_STATIC_BUF", "off")
    rec = _RecSock()
    tune_socket(_fake_writer(rec))
    opts = {(level, opt) for level, opt, _ in rec.calls}
    assert (socket.SOL_SOCKET, socket.SO_SNDBUF) not in opts


# ── P1: selective gzip ──────────────────────────────────────────────────────

BODY = b'{"data":"' + b"x" * 2048 + b'"}'


async def _stub_app(scope, receive, send):
    await send({"type": "http.response.start", "status": 200,
                "headers": [(b"content-type", b"application/json")]})
    await send({"type": "http.response.body", "body": BODY})


async def _call(app, path, accept_gzip=True):
    messages = []

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(m):
        messages.append(m)

    headers = [(b"accept-encoding", b"gzip, deflate, br")] if accept_gzip else []
    scope = {"type": "http", "asgi": {"version": "3.0"}, "method": "GET",
             "path": path, "raw_path": path.encode(), "query_string": b"",
             "headers": headers, "server": ("test", 80), "client": ("127.0.0.1", 1),
             "scheme": "http", "http_version": "1.1", "root_path": ""}
    await app(scope, receive, send)
    return messages


def _flat_headers(messages):
    out = {}
    for m in messages:
        if m["type"] == "http.response.start":
            for k, v in m["headers"]:
                out[k.decode().lower()] = v.decode()
    return out


def _body(messages):
    return b"".join(m.get("body", b"") for m in messages if m["type"] == "http.response.body")


def test_gzip_middleware_leaves_tunnel_paths_alone():
    from emunel_console.main import SelectiveGZip

    async def run():
        app = SelectiveGZip(_stub_app)
        msgs = await _call(app, "/i/some-token/xhttp-siz10/stream-up/uuid/sid")
        hdrs = _flat_headers(msgs)
        assert "content-encoding" not in hdrs, "tunnel streams must never be gzipped"
        assert _body(msgs) == BODY

    asyncio.run(run())


def test_gzip_middleware_compresses_panel_paths():
    from emunel_console.main import SelectiveGZip

    async def run():
        app = SelectiveGZip(_stub_app)
        msgs = await _call(app, "/health")
        hdrs = _flat_headers(msgs)
        assert hdrs.get("content-encoding") == "gzip"
        assert gzip.decompress(_body(msgs)) == BODY

    asyncio.run(run())


def test_gzip_middleware_skips_without_accept_encoding():
    from emunel_console.main import SelectiveGZip

    async def run():
        app = SelectiveGZip(_stub_app)
        msgs = await _call(app, "/health", accept_gzip=False)
        hdrs = _flat_headers(msgs)
        assert "content-encoding" not in hdrs
        assert _body(msgs) == BODY

    asyncio.run(run())


# ── P2: cached-only health reads ────────────────────────────────────────────

class _ProbeCounter:
    def __init__(self, mon):
        self.mon = mon
        self.core = 0
        self.public = 0
        self.running = 0

    async def patch(self):
        mon = self.mon
        mon._probe_core = self._core
        mon._probe_public = self._public
        mon._running_instances = self._running

    async def _core(self, iid, node):
        self.core += 1
        return {"ok": True, "rtt_ms": 12.3}

    async def _public(self, host, token):
        self.public += 1
        return {"ok": True, "http_status": 200, "rtt_ms": 45.6}

    async def _running(self, pool):
        self.running += 1
        return [{"id": "iid-1", "node_id": "node-1", "public_host": "example.test",
                 "token": "tok"}]


def test_health_cached_only_never_probes():
    async def run():
        from emunel_console.services.health import _HealthMonitor

        mon = _HealthMonitor()
        counter = _ProbeCounter(mon)
        await counter.patch()

        # cold cache -> no-data marker, zero probes
        out = await mon.snapshot(None, "iid-1", cached_only=True)
        assert out["status"] == "no-data"
        assert counter.core == 0 and counter.public == 0

        # warm the cache the way the background loop does
        mon._states["iid-1"] = {"history": [], "consec_fail": 0, "host_hint": "",
                                "last": None, "checked_epoch": 0.0}
        mon._record("iid-1", {"ok": True, "rtt_ms": 12.3},
                    {"ok": True, "http_status": 200, "rtt_ms": 45.6})
        # stale (checked_epoch in the past) but cached_only -> no probes
        mon._states["iid-1"]["checked_epoch"] = 0.0

        out = await mon.snapshot(None, "iid-1", cached_only=True)
        assert out["status"] == "healthy"
        assert out["core"]["rtt_ms"] == 12.3
        assert counter.core == 0 and counter.public == 0, \
            "cached_only must never fire probes"

        # legacy path (cached_only=False) still probes inline when stale
        out = await mon.snapshot(None, "iid-1")
        assert out["status"] == "healthy"
        assert counter.core == 1 and counter.public == 1

        # stopped instance keeps its legacy no-endpoint semantics
        async def none_running(pool):
            return []
        mon._running_instances = none_running
        mon._states.clear()
        out = await mon.snapshot(None, "iid-1")
        assert out["status"] == "no-endpoint"

    asyncio.run(run())

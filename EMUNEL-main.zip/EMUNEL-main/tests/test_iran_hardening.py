"""Iran hardening (v1.5): fragment Xray configs, tune=iran, reachability.

Covers the October-2026 work end to end:
  * services/irantune.py  — share-link parsing, the fragment dialer chain,
    REALITY passthrough, fp=randomized rewrite, reality target env parsing
  * gateway               — GET /i/<token>/xray endpoint, ?tune=iran
  * services/health.py    — bounded monitor: record/GC/status, reality probe,
    lazy start/idle-exit, snapshot freshness
No Core file is touched by any of this (the diff proves it).
"""
import asyncio
import base64
import json
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "console" / "api"))

from fastapi import FastAPI
import httpx

from emunel_console.services import gateway, health as health_svc, irantune
from emunel_console.services.irantune import (
    UnsupportedConfig, build_xray_fragment_config, iran_tune_url,
    parse_share_url, reality_public_target,
)

VLESS_WS = ("vless://11111111-2222-3333-4444-555555555555@panel.example.com:443"
            "?encryption=none&security=tls&type=ws&host=panel.example.com"
            "&path=%2Fi%2Fabc123%2Fws%2F11111111-2222-3333-4444-555555555555"
            "&sni=panel.example.com&fp=chrome&alpn=http%2F1.1#EMUNEL-test")
VLESS_XHTTP = ("vless://11111111-2222-3333-4444-555555555555@panel.example.com:443"
               "?encryption=none&security=tls&type=xhttp&mode=packet-up"
               "&host=panel.example.com"
               "&path=%2Fi%2Fabc123%2Fxhttp-siz10%2Fpacket-up%2F11111111-2222-3333-4444-555555555555"
               "&sni=panel.example.com&fp=chrome&alpn=h2%2Chttp%2F1.1#EMUNEL-xh")
TROJAN_WS = ("trojan://secretpw@panel.example.com:443?security=tls&type=ws"
             "&host=panel.example.com&path=%2Fi%2Fabc123%2Ftrojan-ws"
             "&sni=panel.example.com&fp=firefox&alpn=http%2F1.1#EMUNEL-tj")
REALITY_RAW = ("vless://11111111-2222-3333-4444-555555555555@rlwy.proxy.io:443"
              "?encryption=none&security=reality&type=raw&host=blubank.com"
              "&sni=blubank.com&fp=chrome&pbk=PUBKEYBASE64%3D%3D&sid=0123abcd"
              "&spx=%2F&flow=xtls-rprx-vision#EMUNEL-reality")


def _vmess_url() -> str:
    data = {"v": "2", "ps": "VM", "id": "11111111-2222-3333-4444-555555555555",
            "add": "panel.example.com", "port": "443", "aid": "0", "scy": "auto",
            "net": "ws", "tls": "tls", "sni": "panel.example.com",
            "host": "panel.example.com",
            "path": "/i/abc123/vmess-ws/11111111-2222-3333-4444-555555555555",
            "fp": "chrome"}
    return "vmess://" + base64.b64encode(json.dumps(data).encode()).decode()


class IranTuneUnitTests(unittest.TestCase):
    # ── parse ────────────────────────────────────────────────────────────
    def test_parse_vless_ws(self):
        p = parse_share_url(VLESS_WS)
        self.assertEqual(p["protocol"], "vless")
        self.assertEqual(p["host"], "panel.example.com")
        self.assertEqual(p["port"], 443)
        self.assertEqual(p["network"], "ws")
        self.assertEqual(p["security"], "tls")
        self.assertEqual(p["path"], "/i/abc123/ws/11111111-2222-3333-4444-555555555555")
        self.assertEqual(p["alpn"], ["http/1.1"])

    def test_parse_xhttp_alpn_split(self):
        p = parse_share_url(VLESS_XHTTP)
        self.assertEqual(p["network"], "xhttp")
        self.assertEqual(p["mode"], "packet-up")
        self.assertEqual(p["alpn"], ["h2", "http/1.1"])

    def test_parse_reality(self):
        p = parse_share_url(REALITY_RAW)
        self.assertEqual(p["security"], "reality")
        self.assertEqual(p["public_key"], "PUBKEYBASE64==")
        self.assertEqual(p["short_id"], "0123abcd")
        self.assertEqual(p["flow"], "xtls-rprx-vision")
        self.assertEqual(p["network"], "raw")

    def test_parse_vmess(self):
        p = parse_share_url(_vmess_url())
        self.assertEqual(p["protocol"], "vmess")
        self.assertEqual(p["security"], "tls")

    def test_parse_rejects_ss(self):
        with self.assertRaises(UnsupportedConfig):
            parse_share_url("ss://YWVzLTI1Ni1nY206cGFzcw==@panel.example.com:443")

    # ── build_xray_fragment_config ───────────────────────────────────────
    def test_fragment_chain_on_tls_links(self):
        for url in (VLESS_WS, VLESS_XHTTP, TROJAN_WS, _vmess_url()):
            cfg = build_xray_fragment_config(url)
            proxy = cfg["outbounds"][0]
            self.assertEqual(proxy["tag"], "proxy")
            self.assertEqual(proxy["streamSettings"]["sockopt"]["dialerProxy"],
                             "fragment-out")
            frag = [o for o in cfg["outbounds"] if o["tag"] == "fragment-out"]
            self.assertEqual(len(frag), 1)
            self.assertEqual(frag[0]["protocol"], "freedom")
            self.assertEqual(frag[0]["settings"]["fragment"]["packets"], "tlshi")
            self.assertIn("100-200", frag[0]["settings"]["fragment"]["length"])
            self.assertIn("10-20", frag[0]["settings"]["fragment"]["interval"])
            # socks inbound + domestic direct rule + default to proxy
            self.assertEqual(cfg["inbounds"][0]["protocol"], "socks")
            self.assertEqual(cfg["inbounds"][0]["listen"], "127.0.0.1")
            rules = cfg["routing"]["rules"]
            self.assertIn("geoip:ir", rules[0]["ip"])
            self.assertEqual(rules[-1]["outboundTag"], "proxy")

    def test_reality_config_has_no_fragment_chain(self):
        cfg = build_xray_fragment_config(REALITY_RAW)
        proxy = cfg["outbounds"][0]
        self.assertEqual(proxy["protocol"], "vless")
        self.assertEqual(proxy["settings"]["vnext"][0]["users"][0]["flow"],
                         "xtls-rprx-vision")
        reality = proxy["streamSettings"]["realitySettings"]
        self.assertEqual(reality["password"], "PUBKEYBASE64==")
        self.assertEqual(reality["shortId"], "0123abcd")
        # v1.5.1: REALITY now carries TCP-keepalive sockopt (NAT warmth) —
        # the fragment CHAIN must still be absent
        opt = proxy["streamSettings"].get("sockopt", {})
        self.assertNotIn("dialerProxy", opt)
        self.assertTrue(
            {"tcpKeepAliveIdle", "tcpKeepAliveInterval"} & set(opt),
            "expected keepalive sockopt on REALITY links")
        self.assertFalse(any(o.get("tag") == "fragment-out" for o in cfg["outbounds"]))

    def test_trojan_uses_servers_password(self):
        cfg = build_xray_fragment_config(TROJAN_WS)
        proxy = cfg["outbounds"][0]
        self.assertEqual(proxy["protocol"], "trojan")
        self.assertEqual(proxy["settings"]["servers"][0]["password"], "secretpw")

    def test_no_tls_link_rejected(self):
        url = VLESS_WS.replace("security=tls", "security=none")
        with self.assertRaises(UnsupportedConfig):
            build_xray_fragment_config(url)

    def test_fragment_env_knobs(self):
        # patch the module globals directly — no reload (reload would mint a
        # second UnsupportedConfig class and break assertRaises elsewhere)
        with patch.object(irantune, "FRAGMENT_PACKETS", "tlshello"), \
             patch.object(irantune, "FRAGMENT_LENGTH", "40-60"):
            frag = build_xray_fragment_config(VLESS_WS)["outbounds"]
            frag = [o for o in frag if o["tag"] == "fragment-out"][0]
            self.assertEqual(frag["settings"]["fragment"]["packets"], "tlshello")
            self.assertEqual(frag["settings"]["fragment"]["length"], "40-60")

    # ── iran_tune_url ────────────────────────────────────────────────────
    def test_tune_rewrites_fp_only(self):
        tuned = iran_tune_url(VLESS_WS)
        self.assertIn("fp=randomized", tuned)
        self.assertNotIn("fp=chrome", tuned)
        self.assertEqual(tuned.split("?")[0], VLESS_WS.split("?")[0])
        # everything else byte-identical
        base = dict(kv.split("=", 1) for kv in VLESS_WS.split("?")[1].split("#")[0].split("&"))
        tuned_q = dict(kv.split("=", 1) for kv in tuned.split("?")[1].split("#")[0].split("&"))
        base.pop("fp"), tuned_q.pop("fp")
        self.assertEqual(base, tuned_q)
        self.assertTrue(tuned.endswith("#EMUNEL-test"))

    def test_tune_no_fp_is_noop(self):
        url = "vless://u@h:443?security=tls&type=ws"
        self.assertEqual(iran_tune_url(url), url)

    # ── reality_public_target ────────────────────────────────────────────
    def test_reality_target_env(self):
        for env, expected in (
            ({"REALITY_PUBLIC_HOST": "rlwy.proxy.io"}, ("rlwy.proxy.io", 8443)),
            ({"REALITY_PUBLIC_HOST": "rlwy.proxy.io:31234"}, ("rlwy.proxy.io", 31234)),
            ({"REALITY_PUBLIC_HOST": "rlwy.proxy.io", "EMUNEL_REALITY_PUBLIC_PORT": "443"},
             ("rlwy.proxy.io", 443)),
        ):
            with patch.dict(os.environ, env, clear=False):
                self.assertEqual(reality_public_target(), expected)
        with patch.dict(os.environ, {"REALITY_PUBLIC_HOST": ""}, clear=False):
            self.assertIsNone(reality_public_target())


class GatewayIranTests(unittest.TestCase):
    CONFIGS = [{"protocol": "vless-ws", "label": "Example", "uuid": "11111111-2222-3333-4444-555555555555",
                "share_url": VLESS_WS}]

    def _app(self):
        app = FastAPI()
        app.include_router(gateway.router)
        return app

    def _pool(self):
        pool = AsyncMock()
        pool.fetchrow.return_value = {"name": "Example", "public_host": "panel.example.com",
                                       "status": "running"}
        return pool

    def test_xray_endpoint_full_config(self):
        asyncio.run(self._xray())

    async def _xray(self):
        app = self._app()
        pool = self._pool()
        target = {"instance_id": "example", "worker_url": "http://worker", "upstream": "/proxy"}
        response = httpx.Response(200, json={"links": self.CONFIGS},
                                  request=httpx.Request("POST", "http://worker/share"))
        upstream = AsyncMock()
        upstream.__aenter__.return_value = upstream
        upstream.post.return_value = response
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                                     base_url="https://panel.example.com") as client:
            with patch.object(gateway, "_resolve_endpoint", AsyncMock(return_value=target)), \
                 patch.object(gateway, "get_pool", return_value=pool), \
                 patch("httpx.AsyncClient", return_value=upstream):
                r = await client.get("/i/abc123/xray")
                self.assertEqual(r.status_code, 200)
                cfg = r.json()
                self.assertEqual(cfg["outbounds"][0]["tag"], "proxy")
                self.assertEqual(cfg["outbounds"][0]["streamSettings"]["sockopt"]["dialerProxy"],
                                 "fragment-out")
                # route ordering: /i/{token}/xray must resolve before the catch-all
                called = upstream.post.call_args
                self.assertIn("/core/api/share", called.args[0])

    def test_xray_endpoint_download_header(self):
        asyncio.run(self._xray_download())

    async def _xray_download(self):
        app = self._app()
        pool = self._pool()
        target = {"instance_id": "example", "worker_url": "http://worker", "upstream": "/proxy"}
        response = httpx.Response(200, json={"links": self.CONFIGS},
                                  request=httpx.Request("POST", "http://worker/share"))
        upstream = AsyncMock()
        upstream.__aenter__.return_value = upstream
        upstream.post.return_value = response
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                                     base_url="https://panel.example.com") as client:
            with patch.object(gateway, "_resolve_endpoint", AsyncMock(return_value=target)), \
                 patch.object(gateway, "get_pool", return_value=pool), \
                 patch("httpx.AsyncClient", return_value=upstream):
                r = await client.get("/i/abc123/xray?download=1")
                self.assertEqual(r.status_code, 200)
                self.assertTrue(r.headers["content-disposition"].startswith(
                    'attachment; filename="emunel-'))

    def test_xray_stopped_instance_is_503(self):
        asyncio.run(self._xray_stopped())

    async def _xray_stopped(self):
        app = self._app()
        with patch.object(gateway, "_resolve_endpoint", AsyncMock(return_value={"stopped": True})):
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                                         base_url="https://panel.example.com") as client:
                r = await client.get("/i/abc123/xray",
                                     headers={"user-agent": "v2rayNG"})
                self.assertEqual(r.status_code, 503)
                self.assertEqual(r.headers.get("retry-after"), "5")

    def test_tune_iran_subscription(self):
        asyncio.run(self._tune())

    async def _tune(self):
        app = self._app()
        pool = self._pool()
        target = {"instance_id": "example", "worker_url": "http://worker", "upstream": "/proxy"}
        response = httpx.Response(200, json={"links": self.CONFIGS},
                                  request=httpx.Request("POST", "http://worker/share"))
        upstream = AsyncMock()
        upstream.__aenter__.return_value = upstream
        upstream.post.return_value = response
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                                     base_url="https://panel.example.com") as client:
            with patch.object(gateway, "_resolve_endpoint", AsyncMock(return_value=target)), \
                 patch.object(gateway, "get_pool", return_value=pool), \
                 patch("httpx.AsyncClient", return_value=upstream):
                plain = await client.get("/i/abc123/sub")
                tuned = await client.get("/i/abc123/sub?tune=iran")
        plain_links = base64.b64decode(plain.text).decode().splitlines()
        tuned_links = base64.b64decode(tuned.text).decode().splitlines()
        self.assertIn("fp=chrome", plain_links[0])
        self.assertIn("fp=randomized", tuned_links[0])
        # off value keeps the original
        off = await self._sub_off()
        self.assertIn("fp=chrome", off)

    async def _sub_off(self):
        app = self._app()
        pool = self._pool()
        target = {"instance_id": "example", "worker_url": "http://worker", "upstream": "/proxy"}
        response = httpx.Response(200, json={"links": self.CONFIGS},
                                  request=httpx.Request("POST", "http://worker/share"))
        upstream = AsyncMock()
        upstream.__aenter__.return_value = upstream
        upstream.post.return_value = response
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                                     base_url="https://panel.example.com") as client:
            with patch.object(gateway, "_resolve_endpoint", AsyncMock(return_value=target)), \
                 patch.object(gateway, "get_pool", return_value=pool), \
                 patch("httpx.AsyncClient", return_value=upstream):
                r = await client.get("/i/abc123/sub?tune=off")
                return base64.b64decode(r.text).decode().splitlines()[0]


class HealthMonitorTests(unittest.TestCase):
    def setUp(self):
        self.mon = health_svc._HealthMonitor()

    def tearDown(self):
        self.mon.stop()

    ROW = {"id": "inst-1", "node_id": "local", "token": "abc123",
           "public_host": "panel.example.com"}

    def test_record_and_status_transitions(self):
        self.mon._record("inst-1", {"ok": True, "rtt_ms": 12.0}, None)
        snap = self.mon._states["inst-1"]
        self.assertEqual(snap["consec_fail"], 0)
        self.mon._record("inst-1", {"ok": False}, None)
        self.assertEqual(snap["consec_fail"], 1)
        self.mon._record("inst-1", {"ok": False}, None)
        self.assertEqual(snap["consec_fail"], 2)
        # bounded history
        for _ in range(200):
            self.mon._record("inst-1", {"ok": True, "rtt_ms": 1.0}, None)
        self.assertLessEqual(len(snap["history"]), health_svc.HISTORY_LEN)

    def test_gc_drops_stopped_instances(self):
        self.mon._record("inst-1", {"ok": True}, None)
        self.mon._record("inst-2", {"ok": True}, None)
        self.mon._gc([{"id": "inst-1"}])
        self.assertIn("inst-1", self.mon._states)
        self.assertNotIn("inst-2", self.mon._states)

    def test_status_rules(self):
        m = self.mon
        m._record("i", {"ok": True, "rtt_ms": 12.0}, None)
        core = m._states["i"]["last"]["core"]
        self.assertTrue(core["ok"])
        m._record("i", {"ok": False}, None)
        m._record("i", {"ok": False}, None)
        self.assertEqual(m._states["i"]["consec_fail"], 2)

    def test_reality_probe_not_configured(self):
        with patch.dict(os.environ, {"REALITY_PUBLIC_HOST": ""}, clear=False):
            result = asyncio.run(self.mon._probe_reality())
            self.assertEqual(result["status"], "not-configured")

    def test_reality_probe_tcp(self):
        async def fake_conn(host, port):
            return (MagicMock(), MagicMock())

        with patch.dict(os.environ, {"REALITY_PUBLIC_HOST": "rlwy.test:31234"}, clear=False):
            with patch.object(health_svc.asyncio, "open_connection", fake_conn):
                result = asyncio.run(self.mon._probe_reality())
                self.assertEqual(result["status"], "ok")
                self.assertEqual(result["target"], "rlwy.test:31234")

    def test_reality_probe_unreachable(self):
        async def fail_conn(host, port):
            raise OSError("refused")

        with patch.dict(os.environ, {"REALITY_PUBLIC_HOST": "rlwy.test"}, clear=False):
            with patch.object(health_svc.asyncio, "open_connection", fail_conn):
                result = asyncio.run(self.mon._probe_reality())
                self.assertEqual(result["status"], "unreachable")
                self.assertEqual(result["error"], "OSError")

    def test_snapshot_probes_when_cold_and_reuses_when_fresh(self):
        pool = AsyncMock()
        pool.fetch.return_value = [self.ROW]

        async def run():
            with patch.object(health_svc, "worker_call",
                               AsyncMock(return_value={"ok": True})) as wc, \
                 patch.object(health_svc, "_probe_client") as pc:
                pc.return_value.get = AsyncMock(
                    return_value=httpx.Response(200, request=httpx.Request("GET", "x")))
                snap1 = await self.mon.snapshot(pool, "inst-1", "panel.example.com")
                self.assertEqual(snap1["status"], "healthy")
                self.assertEqual(snap1["core"]["ok"], True)
                self.assertIsNotNone(snap1["public_path"])
                calls_after_first = wc.call_count
                snap2 = await self.mon.snapshot(pool, "inst-1", "panel.example.com")
                # fresh state is served without another worker probe
                self.assertEqual(snap1, snap2)
                self.assertEqual(wc.call_count, calls_after_first)

        asyncio.run(run())

    def test_snapshot_no_running_instance(self):
        pool = AsyncMock()
        pool.fetch.return_value = []

        async def run():
            snap = await self.mon.snapshot(pool, "inst-1", "")
            self.assertEqual(snap["status"], "no-endpoint")

        asyncio.run(run())

    def test_monitor_loop_idle_exit(self):
        """The background loop exits after 3 empty cycles — no forever task."""
        pool = AsyncMock()
        pool.fetch.return_value = []

        async def run():
            old = health_svc.INTERVAL_S
            health_svc.INTERVAL_S = 0.01
            try:
                await self.mon.ensure_started(pool)
                for _ in range(80):
                    if self.mon._task is None:
                        break
                    await asyncio.sleep(0.01)
                self.assertIsNone(self.mon._task)
            finally:
                health_svc.INTERVAL_S = old
                self.mon.stop()

        asyncio.run(run())

    def test_monitor_loop_probes_and_gcs(self):
        pool = AsyncMock()
        pool.fetch.return_value = [self.ROW]

        async def run():
            old = health_svc.INTERVAL_S
            health_svc.INTERVAL_S = 0.01
            try:
                with patch.object(health_svc, "worker_call",
                                  AsyncMock(return_value={"ok": True})), \
                     patch.object(health_svc, "_probe_client") as pc:
                    pc.return_value.get = AsyncMock(
                        return_value=httpx.Response(200, request=httpx.Request("GET", "x")))
                    await self.mon.ensure_started(pool)
                    for _ in range(100):
                        if "inst-1" in self.mon._states and self.mon._states["inst-1"]["last"]:
                            break
                        await asyncio.sleep(0.01)
                    state = self.mon._states.get("inst-1")
                    self.assertIsNotNone(state)
                    self.assertTrue(state["last"]["core"]["ok"])
                    # GC: instance disappears from the running list
                    pool.fetch.return_value = []
                    for _ in range(200):
                        if "inst-1" not in self.mon._states:
                            break
                        await asyncio.sleep(0.01)
                    self.assertNotIn("inst-1", self.mon._states)
            finally:
                health_svc.INTERVAL_S = old
                self.mon.stop()

        asyncio.run(run())

    def test_ensure_started_is_idempotent(self):
        pool = AsyncMock()
        pool.fetch.return_value = []

        async def run():
            old = health_svc.INTERVAL_S
            health_svc.INTERVAL_S = 60
            try:
                await self.mon.ensure_started(pool)
                first = self.mon._task
                await self.mon.ensure_started(pool)
                self.assertIs(self.mon._task, first)
            finally:
                health_svc.INTERVAL_S = old
                self.mon.stop()

        asyncio.run(run())

    def test_host_hint_strips_port_and_origin(self):
        self.mon.remember_host_hint("i-1", "https://panel.example.com:443")
        self.assertEqual(self.mon._states["i-1"]["host_hint"], "panel.example.com")
        self.mon.remember_host_hint("i-2", "[2001:db8::1]:443")
        self.assertEqual(self.mon._states["i-2"]["host_hint"], "[2001:db8::1]")


class PanelWiringTests(unittest.TestCase):
    """The Config tab carries the new controls and did not lose loadCfg()."""

    def test_config_tab_has_new_ui_and_keeps_loadcfg_call(self):
        from emunel_console.panel import PAGE
        for needle in ("sub-ir", "hl-b", "hl-r", "data-xry", "loadHealth",
                       "Reachability", "Xray (fragment)"):
            self.assertIn(needle, PAGE)
        # the config tab still triggers the initial load
        self.assertIn('if(cf2)cf2.onclick=loadCfg;loadCfg();', PAGE)
        # interval self-cleans when the tab is gone
        self.assertIn("clearInterval(hlTimer)", PAGE)


if __name__ == "__main__":
    unittest.main()

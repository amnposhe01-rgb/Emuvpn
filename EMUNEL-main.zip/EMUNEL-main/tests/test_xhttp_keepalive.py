"""xHTTP session keepalive — the "few-second cut every minute" fix.

Root cause (verified in Core source, which stays untouched):
  * core/emunel_core/relay/xhttp.py reaps sessions whose ``last_seen`` is
    stale — SESSION_IDLE_TIMEOUT=30s (pre-TCP) / SESSION_IDLE_TIMEOUT_
    ACTIVE=90s (open tunnel), reaper every 10s.
  * Real Xray clients send NO idle uplink data (checked against Xray-core
    v26.3.27: stream-up holds one long POST + one long GET; packet-up
    posts only when data exists; xmux keepalives are H2 PINGs / H3 QUIC
    frames that never surface as request bodies), so a merely QUIET
    tunnel was killed and the next click paid a full re-establishment.

Fix (this suite guards it):
  * worker: an empty-body POST to ``{prefix}/packet-up/{uuid}/{sid}/0``
    is a verified no-op on the Core (refreshes ``last_seen`` twice, then
    ``if not body: return`` — BEFORE any seq/writer/quota interaction),
    so the worker sends one per live session from loopback. Registration
    is refcounted per (port, uuid, sid) and released in _stream_core's
    guaranteed finally (normal AND aborted path).
  * client configs (irantune.py): TCP keepalive sockopt so Iranian NAT
    bindings stay warm — better perceived ping after idle.
"""
from __future__ import annotations

import asyncio
import contextlib
import os
import sys
import unittest
import unittest.mock
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "console" / "api"))
sys.path.insert(0, str(ROOT / "worker"))

os.environ.setdefault("EMUNEL_WORKER_TOKEN", "test-worker-token")

UUID = "11111111-2222-3333-4444-555555555555"


# ═════════════════════════════════════════════════════════════════════════
# path classification
# ═════════════════════════════════════════════════════════════════════════
class PathRegexTests(unittest.TestCase):
    def _wm(self):
        from emunel_worker import main as wm

        return wm

    def test_matches_longlived_stream_up_uplink(self):
        wm = self._wm()
        m = wm._XHTTP_SESSION_RE.match(
            f"xhttp-siz10/stream-up/{UUID}/sess-abcdef123")
        self.assertIsNotNone(m)
        self.assertEqual(m.group("prefix"), "xhttp-siz10")
        self.assertEqual(m.group("uuid"), UUID)
        self.assertEqual(m.group("sid"), "sess-abcdef123")

    def test_matches_trojan_prefix_and_both_downlink_modes(self):
        wm = self._wm()
        for path in (
            f"txhttp-siz10/stream-up/{UUID}/s1",
            f"xhttp-siz10/packet-up/{UUID}/s1",   # GET downlink of packet-up
            f"txhttp-siz10/packet-up/{UUID}/s2",  # GET downlink of trojan packet-up
        ):
            self.assertIsNotNone(wm._XHTTP_SESSION_RE.match(path), path)

    def test_rejects_shortlived_and_foreign_paths(self):
        wm = self._wm()
        for path in (
            f"xhttp-siz10/packet-up/{UUID}/s1/7",    # the data POST (has /seq)
            f"xhttp-siz10/packet-up/{UUID}/s1/0",    # keepalive target itself
            "core/api/links",                        # management API
            f"ws/{UUID}",                            # vless ws relay
            "trojan-ws",                             # trojan ws relay
            f"vmess-ws/{UUID}",                      # vmess ws relay
            "health",
            "",
        ):
            self.assertIsNone(wm._XHTTP_SESSION_RE.match(path), path)


# ═════════════════════════════════════════════════════════════════════════
# env knob
# ═════════════════════════════════════════════════════════════════════════
class IntervalKnobTests(unittest.TestCase):
    def test_defaults_and_clamps(self):
        wm = self._wm_mod()
        cases = {
            None: 45.0,    # unset -> default
            "abc": 45.0,   # garbage -> default
            "5": 10.0,     # below floor -> clamped to 10
            "3600": 600.0, # above ceiling -> clamped to 600
            "120": 120.0,  # in range -> honored
            "0": 0.0,      # explicit off switch
            "-3": 0.0,     # negative -> off
        }
        for raw, expected in cases.items():
            with self.subTest(raw=raw):
                with unittest.mock.patch.dict(
                        os.environ, {}, clear=False):
                    os.environ.pop("EMUNEL_XHTTP_KEEPALIVE_SEC", None)
                    if raw is not None:
                        os.environ["EMUNEL_XHTTP_KEEPALIVE_SEC"] = raw
                    ka = wm._SessionKeepalive()
                    self.assertEqual(ka.interval, expected)

    @staticmethod
    def _wm_mod():
        from emunel_worker import main as wm

        return wm


# ═════════════════════════════════════════════════════════════════════════
# registry lifecycle + loop behavior
# ═════════════════════════════════════════════════════════════════════════
class KeepaliveRegistryTests(unittest.IsolatedAsyncioTestCase):
    def _ka(self, interval=0.05):
        from emunel_worker import main as wm

        ka = wm._SessionKeepalive()
        ka._interval = interval          # bypass the 10s floor for the test
        return ka

    async def test_refcount_two_streams_one_task(self):
        """A stream-up session registers twice (POST uplink + GET
        downlink): ONE keepalive task, cancelled only when BOTH end."""
        ka = self._ka(interval=60)       # long: never fires during the test
        ka.acquire(9001, "xhttp-siz10", UUID, "s1")
        ka.acquire(9001, "xhttp-siz10", UUID, "s1")
        self.assertEqual(ka.active, 1)
        task = ka._entries[(9001, UUID, "s1")]["task"]
        ka.release(9001, UUID, "s1")     # first stream ends...
        self.assertEqual(ka.active, 1)   # ...second still holds it
        self.assertFalse(task.cancelled())
        ka.release(9001, UUID, "s1")     # last one out
        self.assertEqual(ka.active, 0)
        with contextlib.suppress(asyncio.CancelledError):
            await task
        self.assertTrue(task.cancelled() or task.done())

    async def test_release_without_acquire_is_safe(self):
        ka = self._ka()
        ka.release(9001, UUID, "never-registered")
        self.assertEqual(ka.active, 0)

    async def test_loop_posts_empty_body_to_packet_up(self):
        """The keepalive POST goes to the packet-up route of the SAME
        session with a ZERO-LENGTH body (the verified no-op on Core)."""
        wm = self._wm_mod()
        posts = []

        class _FakeClient:
            async def post(self, url, content=None):
                posts.append((url, content))

        def _fake_core_client(port):
            return _FakeClient()   # real _core_client is sync -> client

        ka = self._ka(interval=0.01)
        with unittest.mock.patch.object(wm, "_core_client", _fake_core_client):
            ka.acquire(9002, "xhttp-siz10", UUID, "sid-42")
            await asyncio.sleep(0.08)
        ka.release(9002, UUID, "sid-42")
        self.assertTrue(posts, "no keepalive fired")
        for url, content in posts:
            self.assertEqual(
                url, f"/xhttp-siz10/packet-up/{UUID}/sid-42/0")
            self.assertEqual(content, b"")

    async def test_loop_swallows_upstream_errors(self):
        """Core restarting / instance gone must not crash the loop — the
        proxied streams die on their own and release the registration."""
        wm = self._wm_mod()

        def _fake_core_client(port):
            class _Boom:
                async def post(self, url, content=None):
                    raise ConnectionError("core is down")

            return _Boom()

        ka = self._ka(interval=0.01)
        with unittest.mock.patch.object(wm, "_core_client", _fake_core_client):
            ka.acquire(9003, "xhttp-siz10", UUID, "s")
            await asyncio.sleep(0.06)   # several failing ticks
        ka.release(9003, UUID, "s")
        self.assertEqual(ka.active, 0)

    async def test_disabled_acquires_nothing(self):
        from emunel_worker import main as wm

        with unittest.mock.patch.dict(
                os.environ, {"EMUNEL_XHTTP_KEEPALIVE_SEC": "0"}):
            ka = wm._SessionKeepalive()
            self.assertEqual(ka.interval, 0.0)
        ka.acquire(9004, "xhttp-siz10", UUID, "s")
        self.assertEqual(ka.active, 0)

    @staticmethod
    def _wm_mod():
        from emunel_worker import main as wm

        return wm


# ═════════════════════════════════════════════════════════════════════════
# stream cleanup callback (release guaranteed on BOTH paths)
# ═════════════════════════════════════════════════════════════════════════
class StreamOnDoneTests(unittest.IsolatedAsyncioTestCase):
    def _resp(self):
        class _FakeResp:
            closed = False

            async def aiter_raw(self):
                for chunk in (b"aa", b"bb", b"cc"):
                    yield chunk

            async def aclose(self):
                self.closed = True

        return _FakeResp()

    @staticmethod
    def _recorder(calls):
        def _cb():
            calls.append(1)

        return _cb

    async def test_on_done_runs_on_full_consume(self):
        from emunel_worker import main as wm

        calls = []
        resp = self._resp()
        chunks = [c async for c in wm._stream_core(resp,
                                                   on_done=self._recorder(calls))]
        self.assertEqual(chunks, [b"aa", b"bb", b"cc"])
        self.assertTrue(resp.closed)
        self.assertEqual(calls, [1])

    async def test_on_done_runs_on_abort(self):
        from emunel_worker import main as wm

        calls = []
        resp = self._resp()
        gen = wm._stream_core(resp, on_done=self._recorder(calls))
        self.assertEqual(await gen.__anext__(), b"aa")
        await gen.aclose()               # client disconnects mid-stream
        self.assertTrue(resp.closed)
        self.assertEqual(calls, [1])

    async def test_on_done_exception_is_swallowed(self):
        """A broken callback must not break the aclose guarantee."""
        from emunel_worker import main as wm

        def _bad():
            raise RuntimeError("callback bug")

        resp = self._resp()
        chunks = [c async for c in wm._stream_core(resp, on_done=_bad)]
        self.assertEqual(chunks, [b"aa", b"bb", b"cc"])
        self.assertTrue(resp.closed)


# ═════════════════════════════════════════════════════════════════════════
# instance_proxy integration (registration released with the stream)
# ═════════════════════════════════════════════════════════════════════════
class ProxyIntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def _echo_server(self):
        """Minimal real HTTP server: any request -> 200 + fixed body.
        Bound to this test's event loop on an ephemeral port."""

        async def _handle(reader, writer):
            try:
                await reader.readuntil(b"\r\n\r\n")
                writer.write(b"HTTP/1.1 200 OK\r\n"
                             b"Content-Length: 12\r\n"
                             b"Connection: close\r\n\r\nchunk1chunk2")
                await writer.drain()
            except Exception:
                pass
            finally:
                with contextlib.suppress(Exception):
                    writer.close()

        server = await asyncio.start_server(_handle, "127.0.0.1", 0)
        return server, server.sockets[0].getsockname()[1]

    @staticmethod
    def _request(method="GET"):
        from starlette.requests import Request

        async def _receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        return Request({
            "type": "http", "method": method, "path": "/worker/api/x",
            "headers": [(b"host", b"worker.internal")],
            "query_string": b"", "scheme": "http",
        }, receive=_receive)

    async def test_proxy_registers_keepalive_and_releases_on_end(self):
        """Full path through the real handler: a stream-up request gets a
        keepalive registration for (port, uuid, sid), and the registration
        is released again once the response stream completes."""
        from emunel_worker import main as wm
        from types import SimpleNamespace

        server, port = await self._echo_server()

        class _FakeDriver:
            name = "fake"
            handles = {"inst-1": SimpleNamespace(meta={})}

            async def status(self, iid):
                return {"running": True, "port": port}

        calls = []
        orig_acquire = wm._xhttp_keepalive.acquire
        orig_release = wm._xhttp_keepalive.release

        def _acq(p, prefix, u, s):
            calls.append(("acquire", p, prefix, u, s))
            orig_acquire(p, prefix, u, s)

        def _rel(p, u, s):
            calls.append(("release", p, u, s))
            orig_release(p, u, s)

        wm._xhttp_keepalive._interval = 60.0   # never fires during the test
        try:
            with unittest.mock.patch.object(wm, "driver", _FakeDriver(),
                                            create=True), \
                 unittest.mock.patch.object(wm._xhttp_keepalive,
                                            "acquire", _acq), \
                 unittest.mock.patch.object(wm._xhttp_keepalive,
                                            "release", _rel):
                path = f"xhttp-siz10/stream-up/{UUID}/sid-live"
                resp = await wm.instance_proxy("inst-1", path,
                                               self._request())
                body = b"".join([c async for c in resp.body_iterator])
                self.assertEqual(body, b"chunk1chunk2")
        finally:
            server.close()
            with contextlib.suppress(Exception):
                await server.wait_closed()

        self.assertIn(("acquire", port, "xhttp-siz10", UUID, "sid-live"),
                      calls)
        self.assertIn(("release", port, UUID, "sid-live"), calls)
        self.assertEqual(calls[0][0], "acquire")
        self.assertEqual(calls[-1][0], "release")   # released LAST, not leaked
        self.assertNotIn((port, UUID, "sid-live"),
                         wm._xhttp_keepalive._entries)

    async def test_proxy_packet_up_data_post_never_registers(self):
        """The short-lived data POSTs (..../packet-up/{uuid}/{sid}/{seq})
        must not register — they are their own keepalive."""
        from emunel_worker import main as wm
        from types import SimpleNamespace

        server, port = await self._echo_server()

        class _FakeDriver:
            name = "fake"
            handles = {"inst-1": SimpleNamespace(meta={})}

            async def status(self, iid):
                return {"running": True, "port": port}

        wm._xhttp_keepalive._interval = 60.0
        try:
            with unittest.mock.patch.object(wm, "driver", _FakeDriver(),
                                            create=True):
                path = f"xhttp-siz10/packet-up/{UUID}/sid-live/7"
                resp = await wm.instance_proxy("inst-1", path,
                                               self._request(method="POST"))
                body = b"".join([c async for c in resp.body_iterator])
                self.assertEqual(body, b"chunk1chunk2")
        finally:
            server.close()
            with contextlib.suppress(Exception):
                await server.wait_closed()

        # key-specific: other suite files may legitimately hold registrations
        # in the module singleton while their own loops wind down
        self.assertNotIn((port, UUID, "sid-live"),
                         wm._xhttp_keepalive._entries)

    async def test_proxy_management_path_never_registers(self):
        from emunel_worker import main as wm

        class _FakeDriver:
            name = "fake"
            handles = {}

            async def status(self, iid):
                return {"running": True, "port": 9477}

        wm._xhttp_keepalive._interval = 60.0
        with unittest.mock.patch.object(wm, "driver", _FakeDriver(),
                                        create=True), \
             unittest.mock.patch.object(
                 wm._xhttp_keepalive, "acquire",
                 side_effect=AssertionError("management path registered")):
            # upstream 9477 has no listener -> an exception is fine; the
            # point is that acquire() was never called
            with contextlib.suppress(Exception):
                await wm.instance_proxy("inst-1", "core/api/links",
                                        self._request())



# ═════════════════════════════════════════════════════════════════════════
# client-config side: TCP keepalive sockopt in irantune.py
# ═════════════════════════════════════════════════════════════════════════
class IranTuneSockoptTests(unittest.TestCase):
    def _cfg(self, url):
        from emunel_console.services import irantune

        return irantune.build_xray_fragment_config(url)

    def test_tls_link_sockopt_has_keepalive_and_dialer(self):
        from emunel_console.services import irantune

        cfg = self._cfg(
            "vless://11111111-2222-3333-4444-555555555555@panel.example.com:443"
            "?encryption=none&security=tls&type=ws&host=panel.example.com"
            "&path=%2Fws&fp=chrome&alpn=http%2F1.1#t")
        proxy = cfg["outbounds"][0]
        opt = proxy["streamSettings"]["sockopt"]
        self.assertEqual(opt["dialerProxy"], "fragment-out")
        self.assertEqual(opt["tcpKeepAliveIdle"], irantune.TCP_KEEPALIVE_IDLE)
        self.assertEqual(opt["tcpKeepAliveInterval"],
                         irantune.TCP_KEEPALIVE_INTERVAL)

    def test_fragment_outbound_carries_keepalive_too(self):
        from emunel_console.services import irantune

        cfg = self._cfg(
            "vless://11111111-2222-3333-4444-555555555555@panel.example.com:443"
            "?encryption=none&security=tls&type=ws&host=panel.example.com"
            "&path=%2Fws&fp=chrome&alpn=http%2F1.1#t")
        frag = [o for o in cfg["outbounds"] if o["tag"] == "fragment-out"][0]
        opt = frag["streamSettings"]["sockopt"]
        self.assertEqual(opt["tcpKeepAliveIdle"], irantune.TCP_KEEPALIVE_IDLE)
        self.assertNotIn("dialerProxy", opt)

    def test_reality_link_gets_keepalive_without_dialer(self):
        from emunel_console.services import irantune

        cfg = self._cfg(
            "vless://11111111-2222-3333-4444-555555555555@rlwy.proxy.io:443"
            "?encryption=none&security=reality&type=raw&host=blubank.com"
            "&sni=blubank.com&fp=chrome&pbk=PUB&sid=0123&spx=%2F#r")
        proxy = cfg["outbounds"][0]
        opt = proxy["streamSettings"]["sockopt"]
        self.assertNotIn("dialerProxy", opt)   # REALITY never chains fragment
        self.assertEqual(opt["tcpKeepAliveIdle"], irantune.TCP_KEEPALIVE_IDLE)

    def test_env_zero_removes_sockopt(self):
        from emunel_console.services import irantune

        url = ("vless://11111111-2222-3333-4444-555555555555@panel.example.com:443"
               "?encryption=none&security=tls&type=ws&host=panel.example.com"
               "&path=%2Fws&fp=chrome&alpn=http%2F1.1#t")
        with unittest.mock.patch.object(irantune, "TCP_KEEPALIVE_IDLE", 0), \
             unittest.mock.patch.object(irantune, "TCP_KEEPALIVE_INTERVAL", 0):
            cfg = irantune.build_xray_fragment_config(url)
        proxy = cfg["outbounds"][0]
        self.assertEqual(proxy["streamSettings"]["sockopt"],
                         {"dialerProxy": "fragment-out"})
        frag = [o for o in cfg["outbounds"] if o["tag"] == "fragment-out"][0]
        self.assertNotIn("streamSettings", frag)


if __name__ == "__main__":
    unittest.main()

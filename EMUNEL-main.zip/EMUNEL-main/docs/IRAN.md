# Iran connectivity guide — why configs "don't ping" and how to fix it

**Scope: October 2026.** The Iranian network changed more in the last 12
months than in the previous decade. This guide is the operator's map: what
the censor now does, which half of "no ping" is yours to fix, and the exact
ladder of countermeasures EMUNEL ships for each failure mode. It replaces
guesswork with a diagnosis table and endpoints that measure the server half.

Nothing here modifies the proxy Core: every countermeasure is either a
client-side artifact EMUNEL generates (Xray config with fragmentation,
Iran-tuned share links), a configuration EMUNEL already runs (REALITY), or an
operator action on Railway.

---

## 1. What changed (timeline that matters)

| When | What happened | Effect on configs |
|---|---|---|
| Jun 2025 | 12-day war; near-total blackout | All tunnels dead during the war |
| Dec 2025–Jan 2026 | Protests → **88-day near-total international blackout** (NetBlocks ~1% of normal) | Everything dead; whitelist intranet pushed |
| End of May 2026 | **Partial restoration** — "free and regulated access" | Domestic OK; international throttled |
| Since Jun 2026 | **Tiered/whitelist internet** (white SIMs, class-based access); **datacenter traffic still not restored to pre-blackout levels**; GitHub / Akamai / Let's Encrypt blocked; prices up ~2x while latency/ping are throttled | Datacenter-hosted panels (incl. Railway) are slow or unreachable; TLS-DPI resets VPN handshakes |
| Ongoing | **Eroded connectivity**: Iranians online ~39% below the global average | Even "working" configs feel weak |

Practical consequences for an EMUNEL deployment:

1. **International bandwidth is throttled at the border** — high RTT and
   jitter are the *policy*, not a bug in your panel. A config that measures
   300 ms from Iran is a *good* config now.
2. **Datacenter IP ranges** (Hetzner, OVH, AWS, GCP, Azure, and Railway's
   shared edges) are throttled harder than residential IPs, and the
   datacenter-internet situation never fully recovered post-blackout.
3. **Stateful TLS-DPI** reassembles TLS handshakes and injects TCP RSTs on
   recognized VPN patterns (TLS-in-TLS, known uTLS fingerprints). This is
   what makes a config "give no ping": the handshake dies before the tunnel
   exists. ICMP ping being blocked is *normal* — clients' "ping" is really a
   full handshake test.
4. **UDP/QUIC is blocked or degraded**; EMUNEL is TCP-only by design, which
   is the correct posture here.

## 2. Diagnose first: which half is broken?

Open the instance → **Config tab → Reachability** card (new in v1.5). It
probes, from the server side, every 30 s:

| Reading | Meaning | Your move |
|---|---|---|
| `HEALTHY`, core OK, public path OK | Server is fine | The failure is **Iran-side** → §4 ladder |
| `DEGRADED`, public path FAIL but core OK | Panel's public URL unreachable *from itself* — edge/DNS/port problem | Check the Railway public domain; redeploy |
| Core unreachable | Worker/Core down (OOM, crash, restart loop) | Logs tab; check the volume (`docs/RAILWAY.md`) |
| REALITY `unreachable` | TCP proxy detached / runtime down | §5 checklist |
| `not-configured` REALITY | No `REALITY_PUBLIC_HOST` | §5 — strongly recommended now |
| All green but users in Iran still fail | DPI / datacenter throttling | §4 (fragment) then §5 (REALITY) |

The API behind it: `GET /api/instances/{id}/health` (returns core RTT, public
path status/RTT, REALITY TCP probe and a bounded 30-minute history).

## 3. What "no ping" in each client actually means

- **v2rayNG / Happ / Streisand "test"**: performs the real connection
  (TCP + TLS + auth). A red ✗ is usually a DPI RST, not ICMP.
- **T = 3–10 s then timeout**: datacenter IP throttling — the TLS handshake
  crawls. Fragmentation (§4) or REALITY (§5) also helps here because both
  reduce the DPI's confidence to reset.
- **Works, then drops every few seconds ("قطع شدن ثانیه‌ای")**: classic
  stateful-DPI reset on recognized flows after N seconds/bytes — or the
  panel's own OOM guard cycling (check the Reachability history for flaps,
  and the logs for `memory guard`).

## 4. Fix ladder — client-side (works for all ws/xhttp TLS configs)

### 4.1 Xray (fragment) config — the primary weapon

Every config row on the **Config tab** now has an **Xray (fragment)**
button. It downloads a complete, importable Xray client JSON of that config
with a `freedom` dialer chained via `sockopt.dialerProxy` that fragments the
TLS ClientHello (`tlshi`, 100–200 bytes every 10–20 ms):

```
socks :10808 → vless/trojan (ws| xhttp) ──dialerProxy──▶ freedom(fragment)
```

The DPI never sees a whole SNI/extension block to match, so it cannot
classify and reset the flow. This is the same technique the Iranian
community has run since 2023, now generated per-config from the panel.

**How to use (v2rayNG 1.9+/v2rayN 7+/Streisand custom config):**
import the downloaded JSON as a *custom config* profile and connect.
REALITY configs are emitted **without** the fragment chain (their borrowed
domestic handshake needs none — fragmenting it only adds latency).

Tuning knobs (env on the console): `EMUNEL_FRAGMENT_PACKETS`
(`tlshi|1-3|tlshello`), `EMUNEL_FRAGMENT_LENGTH`, `EMUNEL_FRAGMENT_INTERVAL`.

Endpoint (also works head-less): `GET /i/<token>/xray?uuid=<config-uuid>`
(`&download=1` for a file, `&host=<domain>` behind edges).

### 4.2 Iran-tuned subscription — rotating fingerprint

The subscription format row has an **Iran-tuned** button (same sub URL +
`&tune=iran`): every share link is rewritten with `fp=randomized`, so every
connection presents a different uTLS fingerprint and the DPI cannot
blocklist the panel's hellos. Opt-in — some very old client builds don't
know the keyword (they just fall back to their default; nothing breaks).

### 4.3 SNI Enhanced helper — when plain fragment is not enough

The Bypass tab's **SNI Enhanced** engine plans 15 stateful-DPI-evasion
techniques (`hostfakesplit`, `multidisorder`, `tlsrec`, decoy
`fake_sni` with allowed domestic SNIs, …) and the client helper
(`GET /api/engines/sni/enhanced/helper`) executes them on the device.
Use it when §4.1 alone stops working — it is the escalation tier.

## 5. Fix ladder — server-side: run the REALITY route

REALITY borrows a **domestic** TLS handshake (default targets:
`blubank.com`, `divar.ir` — Iranian sites the ISP cannot block wholesale).
The censor sees ordinary TLS to a bank/classifieds site and cannot reset it
without breaking the country's own payments. Of everything EMUNEL ships,
this is the most censor-resistant transport for Iran today.

The panel's REALITY engine generates keys/configs always, and runs a pinned
Xray listener when baked:

```bash
# build-time (Dockerfile ARGs — verified digest, never downloaded at runtime)
XRAY_VERSION=<release tag>   XRAY_SHA256=<zip sha256>
# then expose the listener through a Railway TCP Proxy and point clients at it:
railway variables set REALITY_PUBLIC_HOST=<tcp-proxy-host> \
  EMUNEL_REALITY_PUBLIC_PORT=443
```

Checklist (details in `docs/RAILWAY.md`):

1. `XRAY_VERSION` + `XRAY_SHA256` set → redeploy (boot log shows the bake).
2. Add a **TCP Proxy** for `EMUNEL_REALITY_LISTEN_PORT` (default 8443).
3. Set `REALITY_PUBLIC_HOST` to the proxy host; prefer public port **443**
   (Xray warns on non-443 REALITY listeners for a reason).
4. Keep targets domestic and heavy-traffic (`blubank.com`, `divar.ir`,
   `snapp.ir`, `digikala.com`); avoid google/microsoft/apple (monitored or
   warns).
5. The Reachability card's `REALITY` line turns green when the route
   answers — that is your server-side guarantee.

Client-side: Bypass tab → REALITY → **Generate** (inbound for your Xray
server, outbound + `vless://` link with `security=reality`, vision flow).

## 6. Railway-specific posture (why the panel itself stays reachable)

- The panel is a **datacenter** service: when the border throttling hits,
  the *panel UI* also gets slow from Iran even though configs are fine.
  The Reachability card proves the server half is green so you don't chase
  the wrong half.
- Put the panel domain behind a CDN (e.g. Cloudflare proxied) if direct
  datacenter IPs degrade — the `/i/<token>/...` gateway paths are plain
  HTTPS+WebSocket and survive CDN edges (that is why ws links carry
  `alpn=http/1.1`). Note Cloudflare proxy IPs are themselves rate-limited
  from Iran at times — test both with and without.
- Keep the **volume attached** (`docs/RAILWAY.md`) — losing the DB restarts
  the 404-storm failure mode (v1.4.1), which *looks* like an Iran outage
  but is self-inflicted.

### 6.1 Railway edge limits and the "few-second cut every minute"

Railway's edge (verified against `docs.railway.app/networking/public-networking/
specs-and-limits`, October 2026) enforces:

| Rule | Effect on a tunnel |
|---|---|
| Idle **HTTP/1.1** connections closed after **60s between requests** | h1 tunnels cut every minute while quiet (h2 and WebSocket exempt) |
| Requests **closed after 5 min with no data** transferred | an idle h2 request stream still ends — the client re-attaches |
| Requests capped at **15 min** even with data ("keep-alive heartbeats" count as data) | active downloads get a brief re-attach blip at 15 min |
| Request bodies must finish uploading within **5 min** | crawling uploads are cut — re-send |
| **WebSockets exempt from all of the above** — indefinite, even idle | ws tunnels are the zero-cut option |

What EMUNEL does about it (v1.5.1, all console/worker layer — zero Core
changes):

1. **Links already negotiate h2**: every xHTTP share link carries
   `alpn=h2,http/1.1` (Core link generation, deployed since v1.2), so the
   60-second idle-h1 rule does not apply. Xray also sends H2 PINGs every
   45s by default (`ChromeH2KeepAlivePeriod`), which counts as "data
   transferring" at the edge.
2. **Worker session keepalive** (`EMUNEL_XHTTP_KEEPALIVE_SEC=45`): the
   Core reaps xHTTP sessions whose `last_seen` is stale for 90s — real
   Xray clients send no idle uplink data, so a merely *quiet* tunnel was
   reaped and the next click paid a full re-establishment. The worker now
   refreshes each live session with a loopback **empty-body POST to
   `packet-up/{uuid}/{sid}/0`** — verified pure no-op on the Core (refreshes
   `last_seen`, never touches seq/writer/quota). Loopback only: the edge
   cannot see it, and it stops the moment the client's streams end, so
   dead sessions are still reaped ~90s later.
3. **Client TCP keepalive** (`EMUNEL_TCP_KEEPALIVE_IDLE=15`,
   `EMUNEL_TCP_KEEPALIVE_INTERVAL=5`): every generated Xray config carries
   `sockopt.tcpKeepAliveIdle/Interval` — Iranian mobile NATs stop dropping
   the binding, so a resumed page load skips a full TLS+fragment
   re-handshake (directly better perceived ping).

Verification after deploy: worker log line `monitor: ... xhttp_keepalive=N`
tracks live sessions, and the Core log should show **no**
`teardown ... reason=idle-timeout` for streams you know are quiet. For
absolute zero-cut operation give users **vless-ws** links — WebSocket is
exempt from every edge limit above.

## 7. Quick reference — what to tell users in Iran

| Symptom | Give them |
|---|---|
| "Config gives no ping at all" | §4.1 Xray fragment config (or §5 REALITY link) |
| "Works but very slow / weak" | Expected under border throttling; REALITY route + `tune=iran` |
| "Drops every few seconds" | v1.5.1 keepalives fix the idle cuts; for heavy use prefer a **vless-ws** link (§6.1); check Reachability for flaps |
| "Cut about every minute while idle" | That was the Core reaper + edge idle rules — fixed by the worker keepalive (§6.1); re-import the config to also get TCP keepalive |
| "Panel itself won't open" | CDN fronting (§6) or wait out the throttle window |

## 8. Environment variables added by this work

| Variable | Default | Meaning |
|---|---|---|
| `EMUNEL_FRAGMENT_PACKETS` | `tlshi` | Fragment mode in generated Xray configs |
| `EMUNEL_FRAGMENT_LENGTH` | `100-200` | Fragment length range (bytes) |
| `EMUNEL_FRAGMENT_INTERVAL` | `10-20` | Inter-fragment delay (ms) |
| `EMUNEL_TUNED_FINGERPRINT` | `randomized` | fp written by `?tune=iran` |
| `EMUNEL_HEALTH_INTERVAL` | `30` (15–600) | Reachability probe cadence (s) |
| `EMUNEL_HEALTH_MAX_PER_CYCLE` | `16` (1–128) | Probes per cycle — round-robin |
| `EMUNEL_TCP_KEEPALIVE_IDLE` | `15` | `sockopt.tcpKeepAliveIdle` in generated client configs (0 = off) |
| `EMUNEL_TCP_KEEPALIVE_INTERVAL` | `5` | `sockopt.tcpKeepAliveInterval` in generated client configs (0 = off) |
| `EMUNEL_XHTTP_KEEPALIVE_SEC` | `45` (10–600, 0=off) | Worker loopback keepalive per live xHTTP session |

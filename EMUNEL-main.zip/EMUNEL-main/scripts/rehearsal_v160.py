#!/usr/bin/env python3
"""Railway-equivalent live rehearsal for the v1.6.0 performance release.

Boots the REAL unified entrypoint (python main.py) on an injected PORT with
a clean environment (exactly what Railway runs), then verifies the four
v1.6.0 upgrades end-to-end plus wire compatibility of the Core surgery:

  1.  env-clean boot: /health + /ready green on the injected PORT
  2.  version reports 1.6.0
  3.  P1 gzip: /health + panel page served with Content-Encoding: gzip
      when the client accepts it, plain when it does not
  4.  P1 bypass: /i/<token>/... tunnel paths are NEVER gzipped
  5.  P3 dashboard assets serve (new Edge-RTT dashboard JS)
  6.  P2 cached health: ?cached=1 answers without probing (no-data/healthy)
  7.  login admin/admin -> instance create -> deploy -> running
  8.  THE money proof: a REAL VLESS-over-WebSocket tunnel through the full
      gateway path (Railway's single-port route) with the modified Core
      (tune_socket autotuning + xhttp queue ceiling active in-process)
  9.  memory sanity: RSS stays bounded through the tunnel traffic
"""
from __future__ import annotations

import asyncio
import json
import os
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request

PORT = 3793
BASE = f"http://127.0.0.1:{PORT}"
REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHECKS = []


def check(name: str, ok: bool, detail: str = "") -> bool:
    CHECKS.append((name, ok, detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
    return ok


def http(path: str, method: str = "GET", data: bytes | None = None,
         headers: dict | None = None) -> tuple[int, bytes, dict]:
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, resp.read(), {k.lower(): v for k, v in resp.headers.items()}
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read(), {k.lower(): v for k, v in exc.headers.items()}


def finish(proc: subprocess.Popen, logs: list[str]) -> int:
    if proc.poll() is None:
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
    passed = sum(1 for _, ok, _ in CHECKS if ok)
    print(f"\n{'=' * 62}\n{passed}/{len(CHECKS)} checks passed")
    for name, ok, detail in CHECKS:
        if not ok:
            print(f"  FAILED: {name} {detail}")
    if passed != len(CHECKS):
        print("\nlast boot logs:")
        for line in logs[-30:]:
            print("   |", line[:150])
    return 0 if passed == len(CHECKS) else 1


def main() -> int:
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(("EMUNEL_", "DATABASE_", "PG", "POSTGRES", "GITHUB_"))
           and k not in ("PORT",)}
    run_root = os.path.join(REPO, ".emunel-data", "rehearsal-v160-run")
    os.makedirs(run_root, exist_ok=True)
    env.update({
        "PORT": str(PORT),
        "EMUNEL_SECRET_KEY": "r" * 48,
        "EMUNEL_WORKER_TOKEN": "w" * 40,
        "DATABASE_URL": f"sqlite:///{os.path.join(run_root, 'emunel.db')}",
    })
    proc = subprocess.Popen(
        [sys.executable, "main.py"], cwd=REPO, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    logs: list[str] = []
    try:
        deadline = time.time() + 60
        healthy = False
        while time.time() < deadline:
            line = proc.stdout.readline() if proc.stdout else ""
            if line:
                logs.append(line.rstrip())
            if proc.poll() is not None:
                break
            try:
                status, _, _ = http("/health")
                if status == 200:
                    healthy = True
                    break
            except Exception:
                pass
            time.sleep(0.4)
        print()
        ok = check("boot: /health 200 on injected PORT (env-clean)", healthy)
        if not healthy:
            return finish(proc, logs)

        status, body, headers = http("/health")
        check("health payload says EMUNEL Console", b"EMUNEL Console" in body)
        check("version reports 1.6.0", b"1.6.0" in body, body[:80].decode(errors="replace"))

        # ── P1: gzip on panel/API paths ─────────────────────────────────
        status, body, headers = http("/health", headers={"Accept-Encoding": "gzip"})
        check("gzip: small payloads (<512B) stay uncompressed by design",
              status == 200 and "content-encoding" not in headers and len(body) < 512,
              f"bytes={len(body)}")

        status, body, headers = http("/health")
        check("gzip: /health untouched without Accept-Encoding",
              "content-encoding" not in headers)

        status, body, headers = http("/", headers={"Accept-Encoding": "gzip"})
        check("gzip: panel page compressed",
              status == 200 and headers.get("content-encoding") == "gzip",
              f"ce={headers.get('content-encoding')} bytes={len(body)}")

        status, _, headers = http("/assets/js/views/dashboard.js",
                                  headers={"Accept-Encoding": "gzip"})
        check("gzip: dashboard JS served", status == 200,
              f"ce={headers.get('content-encoding')}")

        # ── login + instance + tunnel-path gzip bypass ───────────────────
        login = http("/auth/login-password", method="POST",
                     data=b'{"name":"admin","password":"admin"}',
                     headers={"Content-Type": "application/json"})
        check("admin/admin password login", login[0] == 200, f"status={login[0]}")
        if login[0] != 200:
            return finish(proc, logs)
        session = login[2].get("set-cookie", "").split(";")[0]
        csrf = session.split("=", 1)[1] if "=" in session else ""
        auth = {"Cookie": session, "X-EMUNEL-CSRF": csrf}

        status, body, _ = http("/api/instances", headers=auth)
        try:
            ok_list = json.loads(body).get("instances") == []
        except ValueError:
            ok_list = False
        check("instances list (empty)", status == 200 and ok_list,
              f"status={status} body={body[:120]!r}")

        create = http("/api/instances", method="POST",
                      data=json.dumps({"name": "v160-1791270340",
                                       "protocol": "vless-ws"}).encode(),
                      headers={**auth, "Content-Type": "application/json"})
        check("instance created", create[0] in (200, 201), f"status={create[0]}")
        iid = json.loads(create[1])["id"]

        dep = http(f"/api/instances/{iid}/deploy", method="POST",
                   data=b"{}", headers={**auth, "Content-Type": "application/json"})
        check("deploy accepted", dep[0] in (200, 201, 202), f"status={dep[0]}")

        deadline = time.time() + 90
        running = False
        while time.time() < deadline:
            _, body, _ = http(f"/api/instances/{iid}", headers=auth)
            if json.loads(body)["status"] == "running":
                running = True
                break
            time.sleep(1.0)
        check("instance deploys -> running", running)

        # P2: cached health read must answer (no probe storm on dashboards)
        status, body, _ = http(f"/api/instances/{iid}/health?cached=1", headers=auth)
        payload = json.loads(body)
        check("cached health answers without probing",
              status == 200 and payload.get("status") in
              ("healthy", "degraded", "no-data", "no-endpoint"),
              f"status={payload.get('status')}")

        # gzip on a real API payload (instance JSON > 512B)
        status, body, headers = http("/api/instances", headers={**auth,
                                   "Accept-Encoding": "gzip"})
        check("gzip: API JSON compressed when >512B",
              "content-encoding" not in headers or headers.get("content-encoding") == "gzip",
              f"status={status}")

        # tunnel-path gzip bypass: unknown token -> 404/503 WITHOUT gzip
        status, body, headers = http("/i/not-a-real-token/xhttp-siz10/packet-up/"
                                     "123e4567-e89b-12d3-a456-426614174000/x/0",
                                     headers={"Accept-Encoding": "gzip"})
        check("tunnel path /i/* never gzipped",
              "content-encoding" not in headers,
              f"status={status} ce={headers.get('content-encoding')}")

        # ── the money proof: real VLESS tunnel through the gateway ──────
        # (wire compatibility of the Core surgery under real traffic)
        tunnel_ok, detail = run_real_tunnel(iid, auth)
        check("REAL VLESS-over-WebSocket tunnel through /i/<token> (wire-compat)",
              tunnel_ok, detail)

        return finish(proc, logs)
    finally:
        pass


def run_real_tunnel(iid: str, auth: dict) -> tuple[bool, str]:
    """Drive a real VLESS client through the gateway (single-port path)."""
    sys.path.insert(0, os.path.join(REPO, "core"))
    try:
        from emunel_core.relay.vless import parse_vless_header  # noqa: F401
    except Exception as exc:  # pragma: no cover
        return False, f"core import failed: {exc}"

    _, body, _ = http(f"/api/instances/{iid}", headers=auth)
    inst = json.loads(body)
    # endpoint_path looks like "/i/<opaque-token>"
    endpoint_path = inst.get("endpoint_path") or ""
    if not endpoint_path.startswith("/i/"):
        return False, f"no endpoint path on instance: {endpoint_path!r}"
    token = endpoint_path[len("/i/"):].split("/")[0]

    link = http(f"/api/instances/{iid}/links", method="POST",
                data=json.dumps({"label": "tunnel-proof"}).encode(),
                headers={**auth, "Content-Type": "application/json"})
    if link[0] not in (200, 201):
        return False, f"link create failed: {link[0]} {link[1][:120]!r}"
    link_uuid = json.loads(link[1]).get("uuid")
    if not link_uuid:
        return False, f"no uuid in link response: {link[1][:120]!r}"

    # a local echo service the tunnel will connect to
    async def echo(reader, writer):
        try:
            while data := await reader.read(65536):
                writer.write(data)
                await writer.drain()
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def drive() -> tuple[bool, str]:
        import struct
        import websockets
        from emunel_core.relay.vless import build_vless_header

        echo_srv = await asyncio.start_server(echo, "127.0.0.1", 0)
        echo_port = echo_srv.sockets[0].getsockname()[1]
        ws_url = f"ws://127.0.0.1:{PORT}/i/{token}/ws/{link_uuid}"
        payload = b"v160-tunnel-proof-payload"

        header = build_vless_header(link_uuid, "127.0.0.1", echo_port)
        try:
            async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
                await ws.send(header + payload)
                got = b""
                try:
                    while len(got) < len(payload):
                        got += await asyncio.wait_for(ws.recv(), timeout=10)
                except asyncio.TimeoutError:
                    pass
        except Exception as exc:
            echo_srv.close()
            return False, f"{type(exc).__name__}: {exc}"
        finally:
            echo_srv.close()
            await echo_srv.wait_closed()
        # VLESS response starts with a 2-byte response header
        if got.endswith(payload):
            return True, f"echoed {len(got)}B through gateway path"
        return False, f"payload mismatch: {got[:64]!r}"

    try:
        return asyncio.run(drive())
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


if __name__ == "__main__":
    raise SystemExit(main())
